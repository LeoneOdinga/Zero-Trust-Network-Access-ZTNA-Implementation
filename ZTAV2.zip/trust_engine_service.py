# ─────────────────────────────────────────────────────────────
# trust_engine_service.py
# Moteur de confiance — port 5001
#
# Cinq signaux pondérés lus depuis policies.yaml :
#   identité       (0.25) — correspondance rôle-ressource, bonus multi-rôles
#   authentification (0.20) — fraîcheur du jeton, méthode AMF
#   appareil       (0.25) — OS, navigateur, type d'appareil, versions
#   réseau         (0.20) — réputation IP, renseignement, géolocalisation
#   comportemental (0.10) — heure d'accès, risque connexion, historique
#
# Démarrage : python trust_engine_service.py
# ─────────────────────────────────────────────────────────────

import logging
import os
import re
import time
import yaml
import requests
from datetime import datetime
from flask import Flask, request, jsonify
from signin_tracker  import get_risk_score, get_user_history
from device_registry import get_telemetry, is_device_fresh
from device_trust    import device_signal_from_telemetry

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [TRUST ENGINE] [%(levelname)s] %(message)s"
)
logger      = logging.getLogger(__name__)
app         = Flask(__name__)
POLICY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policies.yaml")


def _load_policies() -> dict:
    with open(POLICY_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)



def _parse_time_str(t: str) -> int:
    """
    Parse a time string into total seconds since midnight.
    Handles HH:MM, HH:MM:SS, and malformed HH:MM:SS:00 gracefully.
    Only the first three parts (H, M, S) are used.
    """
    parts = str(t).strip().split(":")
    h = int(parts[0]) if len(parts) > 0 else 0
    m = int(parts[1]) if len(parts) > 1 else 0
    s = int(parts[2]) if len(parts) > 2 else 0
    return h * 3600 + m * 60 + s

# ── Santé ────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"service": "trust_engine", "status": "online", "port": 5001}), 200


# ── Evaluate ──────────────────────────────────────────────────

@app.route("/evaluate", methods=["POST"])
def evaluate():
    """
    Expected JSON:
    {
        "user_id":        str,
        "user_roles":     list[str],
        "resource_id":    str,
        "ip_address":     str,
        "user_agent":     str,
        "token_iat":      int | null,
        "mfa_method":     str | null    e.g. "totp", "push", "none"
    }
    Returns:
    {
        "trust_score": int (0-100),
        "breakdown": {
            "identity":       { score, weight, detail },
            "authentication": { score, weight, detail },
            "device":         { score, weight, detail },
            "network":        { score, weight, detail },
            "behavioural":    { score, weight, detail }
        },
        "device_info": { os, browser, device_type, ... },
        "deny_reason": str | null   # hard deny before scoring
    }
    """
    d = request.get_json(silent=True)
    if not d:
        return jsonify({"error": "Missing JSON body"}), 400

    user_id     = d.get("user_id",     "")
    user_roles  = d.get("user_roles",  [])
    resource_id = d.get("resource_id", "")
    ip_address  = d.get("ip_address",  "")
    user_agent  = d.get("user_agent",  "")
    token_iat   = d.get("token_iat",   None)
    mfa_method  = d.get("mfa_method",  None)
    device_id   = d.get("device_id",   None)
    public_ip   = (d.get("public_ip")  or "").strip()

    # Détermination de l'IP effective pour le scoring réseau.
    # Privilégie l'IP publique rapportée par le navigateur when it is a real public address.
    # Repli sur ip_address (détectée côté portail) si public_ip est absente
    # ou est elle-même une adresse privée.
    if public_ip and not _is_private_ip(public_ip):
        network_ip = public_ip
        logger.info(
            f"Evaluate: using browser-reported public IP {network_ip} "
            f"for network scoring (request arrived from {ip_address})"
        )
    else:
        network_ip = ip_address
        if public_ip:
            logger.debug(
                f"Evaluate: browser-reported IP {public_ip} is private — "
                f"falling back to {ip_address} for network scoring"
            )
        else:
            logger.debug(
                f"Evaluate: no public IP provided by browser — "
                f"using {ip_address} for network scoring"
            )

    logger.info(
        f"Evaluate: user={user_id[:8]}... roles={user_roles} "
        f"resource={resource_id} request_ip={ip_address} network_ip={network_ip}"
    )

    try:
        pol = _load_policies()
    except Exception as e:
        logger.error(f"Policy load failed: {e}")
        return jsonify({"error": "Could not load policies"}), 503

    weights = pol.get("trust_weights", {
        "identity": 0.25, "authentication": 0.20,
        "device": 0.25,   "network": 0.20, "behavioural": 0.10
    })

    # Analyse des infos d'appareil une fois — utilisée par plusieurs scoreurs
    device_info = _parse_user_agent(user_agent)

    # ── Hard deny checks (before scoring) ─────────────────────
    # Vérification 1 : présence de l'agent (refus si pas de pulsation récente)
    agent_telemetry = None
    agent_deny      = _check_agent_presence(device_id, pol)
    if agent_deny:
        logger.warning(f"Hard deny (no agent): {agent_deny}")
        return jsonify({
            "trust_score": 0,
            "breakdown":   {},
            "device_info": device_info,
            "deny_reason": agent_deny,
        }), 200

    # Chargement de la télémétrie de l'agent si disponible
    if device_id:
        agent_telemetry = get_telemetry(device_id)

    # ── Refus total : processus IOC / mouvement latéral détecté ──
    # Si l'agent signale un processus malveillant, refus immédiat.
    # Aucune règle ne peut le contourner — il s'applique avant
    # l'évaluation et avant d'atteindre le moteur de politiques.
    if agent_telemetry:
        procs     = agent_telemetry.get("processes", {}) or {}
        ioc_list  = procs.get("ioc_detected", []) or []
        triggered = procs.get("hard_deny_triggered", False)
        if triggered or ioc_list:
            ioc_names = ioc_list if ioc_list else ["unknown malicious process"]
            msg = (
                f"Access denied — lateral movement / malicious process "
                f"detected on this device: {', '.join(ioc_names)}. "
                f"Isolate the device and contact your security administrator."
            )
            logger.warning(
                f"Hard deny (IOC): device_id={device_id} "
                f"processes={ioc_names}"
            )
            return jsonify({
                "trust_score": 0,
                "breakdown":   {},
                "device_info": device_info,
                "deny_reason": msg,
            }), 200

    # Vérification 2 : refus standards (bot UA, AbuseIPDB, etc.)
    # Récupération du score AbuseIPDB une seule fois et mise en cache
    # pour que _check_hard_denies et _score_network puissent l'utiliser
    # un second appel HTTP.
    net_pol_ref = pol.get("network_policy", {})
    api_key_ref = net_pol_ref.get("abuseipdb_api_key", "")
    cached_abuse_score = None
    if api_key_ref and not _is_private_ip(network_ip):
        cached_abuse_score = _check_abuseipdb(network_ip, api_key_ref)
        logger.info(
            f"evaluate: AbuseIPDB score for {network_ip} = "
            f"{cached_abuse_score}/100 (fetched once, shared with scorer)"
        )

    deny_reason = _check_hard_denies(
        network_ip, user_agent, device_info, pol,
        abuse_score=cached_abuse_score
    )
    if deny_reason:
        logger.warning(f"Hard deny: {deny_reason}")
        return jsonify({
            "trust_score": 0,
            "breakdown": {},
            "device_info": device_info,
            "deny_reason": deny_reason,
        }), 200

    # ── Score each signal ──────────────────────────────────────
    id_s,   id_d   = _score_identity(user_roles, resource_id, pol)
    auth_s, auth_d = _score_authentication(token_iat, mfa_method)
    dev_s,  dev_d  = _score_device(device_info, pol, agent_telemetry)
    net_s,  net_d  = _score_network(network_ip, pol, abuse_score=cached_abuse_score)
    beh_s,  beh_d  = _score_behavioural(user_id, pol)

    w_id   = float(weights.get("identity",       0.25))
    w_auth = float(weights.get("authentication", 0.20))
    w_dev  = float(weights.get("device",         0.25))
    w_net  = float(weights.get("network",        0.20))
    w_beh  = float(weights.get("behavioural",    0.10))

    raw   = (w_id*id_s + w_auth*auth_s + w_dev*dev_s +
             w_net*net_s + w_beh*beh_s)
    score = min(round(raw * 100), 100)

    logger.info(
        f"Score={score} | id={id_s:.2f}(w={w_id}) "
        f"auth={auth_s:.2f}(w={w_auth}) dev={dev_s:.2f}(w={w_dev}) "
        f"net={net_s:.2f}(w={w_net}) beh={beh_s:.2f}(w={w_beh})"
    )

    # Enrichissement de device_info avec la télémétrie agent pour que
    # les conditions de règles (device_encrypted, av_enabled, firewall_enabled,
    # agent_status) fonctionnent correctement dans l'évaluateur.
    if agent_telemetry:
        device_info["agent_status"]    = "online"
        device_info["device_encrypted"]= bool(
            (agent_telemetry.get("encryption") or {}).get("enabled")
        )
        device_info["av_enabled"]      = bool(
            (agent_telemetry.get("antivirus") or {}).get("av_enabled")
        )
        device_info["firewall_enabled"]= bool(
            (agent_telemetry.get("firewall") or {}).get("enabled")
        )
        device_info["realtime_av"]     = bool(
            (agent_telemetry.get("antivirus") or {}).get("realtime_enabled")
        )
        device_info["domain_joined"]   = bool(
            (agent_telemetry.get("domain") or {}).get("domain_joined")
        )
        device_info["ioc_detected"]    = bool(
            (agent_telemetry.get("processes") or {}).get("hard_deny_triggered")
        )
        patch_days = (agent_telemetry.get("patch") or {}).get(
            "days_since_last_update", -1
        )
        device_info["patch_days"]      = patch_days
        device_info["device_score"]    = dev_s
    elif device_id:
        # Enregistré mais pulsation obsolète
        device_info["agent_status"] = "stale"
    else:
        # Aucun agent du tout
        device_info["agent_status"] = "never"

    return jsonify({
        "trust_score": score,
        "device_info": device_info,
        "deny_reason": None,
        "breakdown": {
            "identity":       {"score": id_s,   "weight": w_id,   "detail": id_d},
            "authentication": {"score": auth_s, "weight": w_auth, "detail": auth_d},
            "device":         {"score": dev_s,  "weight": w_dev,  "detail": dev_d},
            "network":        {"score": net_s,  "weight": w_net,  "detail": net_d},
            "behavioural":    {"score": beh_s,  "weight": w_beh,  "detail": beh_d},
        }
    }), 200


# ── Hard deny checks ──────────────────────────────────────────

def _check_agent_presence(device_id: str, pol: dict) -> str | None:
    """
    Hard deny if the device does not have a fresh agent heartbeat.

    Grace window: if the device IS registered but has never sent a
    heartbeat (first login race), allow a 30-second window before
    denying. This prevents blocking users immediately after login
    before the agent's first sync completes.

    Returns a denial reason string or None to allow scoring.
    """
    import time as _time

    if not device_id:
        return (
            "Access denied — no device agent detected. "
            "Install and start the ZT Agent on this device before requesting access."
        )

    from device_registry import get_device_info
    device = get_device_info(device_id)

    if not device:
        return (
            f"Access denied — device ID {device_id[:12]}... is not registered. "
            "Re-run the agent to register this device."
        )

    # Appareil enregistré — vérification de la fraîcheur de la pulsation
    if is_device_fresh(device_id):
        return None   # Agent confirmed running

    last_seen = device.get("last_seen")

    if not last_seen:
        # Enregistré mais aucune pulsation — fenêtre de grâce (30s)
        registered = device.get("registered", "")
        try:
            from datetime import datetime as _dt, timezone as _tz
            reg_time  = _dt.fromisoformat(registered.replace("Z", "+00:00"))
            age_sec   = (_dt.now(_tz.utc) - reg_time).total_seconds()
            grace_sec = int(
                pol.get("device_trust_policy", {})
                   .get("first_heartbeat_grace_seconds", 30)
            )
            if age_sec <= grace_sec:
                logger.info(
                    f"_check_agent_presence: device {device_id[:12]}... registered "
                    f"{age_sec:.0f}s ago — within {grace_sec}s grace window"
                )
                return None   # Allow — first heartbeat likely in flight
        except Exception:
            pass
        return (
            f"Access denied — device agent registered but no heartbeat received yet. "
            f"Ensure the ZT Agent is running and the portal is reachable."
        )

    # A déjà envoyé des pulsations mais la pulsation actuelle est obsolète
    return (
        f"Access denied — device agent heartbeat is stale for device "
        f"{device_id[:12]}.... Ensure the ZT Agent is still running."
    )


def _check_hard_denies(ip, ua, device_info, pol,
                       abuse_score=None) -> str | None:
    """
    Returns a denial reason string if the request must be hard-denied
    before trust scoring begins. Returns None if scoring should proceed.

    abuse_score: pre-fetched AbuseIPDB score (0-100) passed from evaluate()
    to avoid a second HTTP call. If None the function fetches it itself.
    """
    dev_pol = pol.get("device_policy", {})

    # Bloquer immédiatement les navigateurs sans interface et les bots
    blocked = [d.lower() for d in dev_pol.get("blocked_device_types", ["headless"])]
    if device_info.get("device_type", "").lower() in blocked:
        return (
            f"Device type '{device_info.get('device_type')}' is not permitted. "
            f"Automated tools and headless browsers are blocked."
        )

    # Block known bot user agents
    bot_signals = ["curl", "wget", "python-requests", "scrapy",
                   "go-http-client", "java/", "libwww"]
    ua_lower = ua.lower()
    for sig in bot_signals:
        if sig in ua_lower:
            return (
                f"Request blocked — automated client detected "
                f"({sig} in User-Agent)."
            )

    # Renseignement AbuseIPDB — blocage total seulement (niveau 4 : score >= seuil)
    # Les pénalités échelonnées pour les scores inférieurs s'appliquent dans _score_network().
    net_pol    = pol.get("network_policy", {})
    api_key    = net_pol.get("abuseipdb_api_key", "")
    hard_deny  = int(net_pol.get("abuseipdb_hard_deny_threshold", 95))

    if not api_key:
        logger.debug(
            f"_check_hard_denies: AbuseIPDB key not configured — "
            f"threat intel check skipped for {ip}"
        )
    elif _is_private_ip(ip):
        logger.debug(
            f"_check_hard_denies: {ip} is private — "
            f"AbuseIPDB check skipped"
        )
    else:
        if abuse_score is None:
            logger.debug(
                f"_check_hard_denies: no pre-fetched score — "
                f"querying AbuseIPDB for {ip} "
                f"(hard deny threshold={hard_deny}/100)"
            )
            abuse_score = _check_abuseipdb(ip, api_key)
        else:
            logger.debug(
                f"_check_hard_denies: using pre-fetched AbuseIPDB score "
                f"{abuse_score}/100 for {ip}"
            )
        if abuse_score is None:
            logger.warning(
                f"_check_hard_denies: AbuseIPDB query returned None for {ip} "
                f"— check API key and network connectivity"
            )
        else:
            logger.info(
                f"_check_hard_denies: AbuseIPDB score for {ip} = "
                f"{abuse_score}/100 (hard deny threshold: {hard_deny}/100)"
            )
            if abuse_score >= hard_deny:
                logger.warning(
                    f"_check_hard_denies: HARD DENY — {ip} AbuseIPDB score "
                    f"{abuse_score} >= hard deny threshold {hard_deny}"
                )
                return (
                    f"IP {ip} has an AbuseIPDB confidence score of {abuse_score}/100 "
                    f"which meets the hard-deny threshold of {hard_deny}/100. "
                    f"Access denied — confirmed malicious IP."
                )
            else:
                logger.debug(
                    f"_check_hard_denies: {ip} below hard deny threshold "
                    f"({abuse_score} < {hard_deny}) — tiered penalties "
                    f"will be applied in network scoring"
                )

    return None


# ── Signal scorers ────────────────────────────────────────────

def _score_identity(user_roles, resource_id, pol):
    """
    0.25 weight.
    Score based on role-resource match and multi-role strength.
    1.0 = privileged role with exact resource match
    0.8 = standard role with resource match
    0.5 = authenticated but role not listed for this resource
    0.0 = no roles
    """
    if not user_roles:
        return 0.0, "No roles assigned to this user."

    permitted = pol.get("resources", {}).get(resource_id, {}).get("roles", {})

    matched_roles = [r for r in user_roles if r in permitted]

    if not matched_roles:
        return 0.5, (
            f"User is authenticated but roles {user_roles} are not "
            f"listed for resource '{resource_id}'."
        )

    # Score basé sur le rôle correspondant au privilège le plus élevé
    privileged_roles = {"System Administrator", "Database Administrator"}
    if any(r in privileged_roles for r in matched_roles):
        base = 1.0
    else:
        base = 0.85

    # Multi-role bonus — user holds more than one permitted role
    if len(matched_roles) > 1:
        base = min(base + 0.05, 1.0)
        detail = (
            f"Roles {matched_roles} all permitted for '{resource_id}'. "
            f"Multi-role bonus applied."
        )
    else:
        detail = f"Role '{matched_roles[0]}' permitted for '{resource_id}'."

    return round(base, 4), detail


def _score_authentication(token_iat, mfa_method):
    """
    0.20 weight.
    Token freshness (70%) + MFA method strength (30%).
    """
    parts = []

    # Token freshness
    if token_iat is None:
        fresh_score = 0.50
        parts.append("Token issue time unavailable — neutral.")
    else:
        age = (time.time() - token_iat) / 60
        if age < 5:
            fresh_score = 1.0
            parts.append(f"Token age {age:.1f} min — very fresh.")
        elif age < 15:
            fresh_score = 0.85
            parts.append(f"Token age {age:.1f} min — fresh.")
        elif age < 30:
            fresh_score = 0.65
            parts.append(f"Token age {age:.1f} min — acceptable.")
        elif age < 60:
            fresh_score = 0.45
            parts.append(f"Token age {age:.1f} min — ageing.")
        else:
            fresh_score = 0.20
            parts.append(f"Token age {age:.1f} min — stale, re-auth recommended.")

    # Force de la méthode AMF
    mfa_scores = {
        "totp":         1.0,    # Time-based OTP — strong
        "push":         0.95,   # Push notification — strong
        "sms":          0.60,   # SMS — weaker, SIM-swap risk
        "email":        0.55,   # Email OTP — weakest MFA
        "webauthn":     1.0,    # FIDO2/WebAuthn — strongest
        "none":         0.20,   # No MFA — significant penalty
        None:           0.50,   # Unknown — neutral
    }
    mfa_score = mfa_scores.get(mfa_method, 0.50)

    if mfa_method and mfa_method != "none":
        parts.append(f"MFA method: {mfa_method} (score {mfa_score:.2f}).")
    elif mfa_method == "none":
        parts.append("No MFA used — significant trust penalty.")
    else:
        parts.append("MFA method unknown — neutral score.")

    # Weighted combination: 70% freshness, 30% MFA
    combined = round(0.70 * fresh_score + 0.30 * mfa_score, 4)
    return combined, " | ".join(parts)


def _score_device(device_info, pol, agent_telemetry=None):
    """
    0.25 weight.
    Score based on OS, browser, device type, and version hygiene.
    """
    dev_pol = pol.get("device_policy", {})

    # If agent telemetry is available, use it for a richer device score.
    # Pass the device_trust_policy sub-section so all penalty values
    # are read from policies.yaml (Policy Administrator can adjust them).
    if agent_telemetry:
        device_trust_pol = pol.get("device_trust_policy", dev_pol)
        tel_score, tel_detail = device_signal_from_telemetry(
            agent_telemetry, device_trust_pol
        )
        return tel_score, f"[Agent] {tel_detail}"

    # Fallback: User-Agent parsing only (agent not installed or telemetry unavailable)
    score   = 1.0
    parts   = []

    device_type  = device_info.get("device_type",  "unknown")
    os_name      = device_info.get("os",            "unknown")
    os_version   = device_info.get("os_version",    "")
    browser      = device_info.get("browser",       "unknown")
    browser_ver  = device_info.get("browser_version", "")

    # Device type
    if device_type == "mobile":
        penalty = float(dev_pol.get("mobile_penalty", 0.15))
        score  -= penalty
        parts.append(f"Mobile device — higher risk (-{penalty})")
    elif device_type == "desktop":
        parts.append("Desktop device — trusted type")
    elif device_type == "tablet":
        parts.append("Tablet device — acceptable")
    else:
        score -= 0.10
        parts.append(f"Unknown device type — small penalty (-0.10)")

    # OS
    trusted_os = [o.lower() for o in dev_pol.get("trusted_os", [])]
    if os_name.lower() in trusted_os:
        parts.append(f"OS: {os_name} {os_version} — trusted")
    elif os_name.lower() not in ("unknown", ""):
        penalty = float(dev_pol.get("untrusted_os_penalty", 0.15))
        score  -= penalty
        parts.append(f"OS: {os_name} — untrusted (-{penalty})")
    else:
        score -= 0.10
        parts.append("OS unknown — small penalty (-0.10)")

    # Browser
    trusted_browsers = [b.lower() for b in dev_pol.get("trusted_browsers", [])]
    if browser.lower() in trusted_browsers:
        parts.append(f"Browser: {browser} {browser_ver} — trusted")
    elif browser.lower() not in ("unknown", ""):
        penalty = float(dev_pol.get("untrusted_browser_penalty", 0.10))
        score  -= penalty
        parts.append(f"Browser: {browser} — untrusted (-{penalty})")
    else:
        score -= 0.05
        parts.append("Browser unknown — small penalty (-0.05)")

    return round(max(0.0, min(1.0, score)), 4), " | ".join(parts)


def _score_network(ip, pol, abuse_score=None):
    """
    0.20 weight.
    Score based on IP type, geolocation, and threat signals.

    abuse_score: pre-fetched AbuseIPDB score passed from evaluate()
    to avoid a second HTTP call. If None and API key is configured,
    the function fetches it itself.
    """
    net_pol = pol.get("network_policy", {})
    score   = 1.0
    parts   = []

    logger.debug(f"_score_network: evaluating ip={ip}")

    # IP privée/interne — entièrement fiable
    if _is_private_ip(ip):
        logger.debug(
            f"_score_network: {ip} is a private/internal address — "
            f"network score = 1.0, all geo/threat checks bypassed"
        )
        parts.append("Private/internal IP — trusted network")
        return 1.0, " | ".join(parts)

    # IP publique — résolution via ipinfo.io
    logger.debug(f"_score_network: querying ipinfo.io for {ip}")
    ip_data = _get_ip_info(ip)

    if not ip_data:
        logger.warning(
            f"_score_network: ipinfo.io returned no data for {ip} — "
            f"check internet connectivity from the Trust Engine host"
        )
    else:
        logger.info(
            f"_score_network: ipinfo.io result for {ip} — "
            f"country={ip_data.get('country','?')} "
            f"city={ip_data.get('city','?')} "
            f"org='{ip_data.get('org','?')}' "
            f"region={ip_data.get('region','?')}"
        )

    org     = ip_data.get("org",      "").lower()
    country = ip_data.get("country",  "")
    city    = ip_data.get("city",     "")

    # Détection du type d'IP
    vpn_keywords     = ["vpn", "nordvpn", "expressvpn", "surfshark",
                        "protonvpn", "mullvad", "privateinternetaccess"]
    proxy_keywords   = ["proxy", "squid", "privoxy"]
    tor_keywords     = ["tor", "onion", "exit node"]
    hosting_keywords = ["hosting", "datacenter", "amazon", "google",
                        "microsoft", "digitalocean", "linode", "vultr",
                        "cloudflare", "ovh", "hetzner", "aws"]

    if any(k in org for k in tor_keywords):
        penalty = float(net_pol.get("tor_penalty", 0.60))
        score  -= penalty
        parts.append(f"Tor exit node detected (-{penalty}) — high risk")
    elif any(k in org for k in proxy_keywords):
        penalty = float(net_pol.get("proxy_penalty", 0.30))
        score  -= penalty
        parts.append(f"Proxy detected: {org} (-{penalty})")
    elif any(k in org for k in vpn_keywords):
        penalty = float(net_pol.get("vpn_penalty", 0.25))
        score  -= penalty
        parts.append(f"VPN detected: {org} (-{penalty})")
    elif any(k in org for k in hosting_keywords):
        penalty = float(net_pol.get("hosting_penalty", 0.20))
        score  -= penalty
        parts.append(f"Hosting/datacenter IP: {org} (-{penalty})")
    else:
        parts.append(f"Clean public IP from {org or 'unknown org'}")
        logger.debug(f"_score_network: {ip} classified as clean public IP (org='{org}')")

    # Risque géographique
    high   = [c.upper() for c in net_pol.get("high_risk_countries",   [])]
    medium = [c.upper() for c in net_pol.get("medium_risk_countries", [])]

    high_list   = ", ".join(high)   if high   else "none configured"
    medium_list = ", ".join(medium) if medium else "none configured"
    logger.debug(
        f"_score_network: geolocation check — "
        f"country={country!r} "
        f"high_risk_list=[{high_list}] "
        f"medium_risk_list=[{medium_list}]"
    )

    if country.upper() in high:
        penalty = float(net_pol.get("high_risk_penalty", 0.40))
        score  -= penalty
        parts.append(f"High-risk country: {country} ({city}) (-{penalty})")
        logger.warning(
            f"_score_network: {ip} from HIGH-RISK country {country} — "
            f"penalty -{penalty} applied"
        )
    elif country.upper() in medium:
        penalty = float(net_pol.get("medium_risk_penalty", 0.20))
        score  -= penalty
        parts.append(f"Medium-risk country: {country} ({city}) (-{penalty})")
        logger.info(
            f"_score_network: {ip} from medium-risk country {country} — "
            f"penalty -{penalty} applied"
        )
    elif country:
        parts.append(f"Country: {country} ({city}) — low risk")
        logger.debug(
            f"_score_network: {ip} from low-risk country {country} ({city}) — "
            f"no geolocation penalty"
        )
    else:
        score -= 0.05
        parts.append("Country unresolvable (-0.05)")
        logger.warning(
            f"_score_network: could not resolve country for {ip} — "
            f"small penalty -0.05 applied"
        )

    # Pénalités AbuseIPDB échelonnées (score < seuil de blocage total)
    api_key    = net_pol.get("abuseipdb_api_key", "")
    hard_deny  = int(net_pol.get("abuseipdb_hard_deny_threshold", 95))
    tier1_min  = int(net_pol.get("abuseipdb_tier1_min",  50))
    tier1_pen  = float(net_pol.get("abuseipdb_tier1_penalty", 0.15))
    tier2_min  = int(net_pol.get("abuseipdb_tier2_min",  70))
    tier2_pen  = float(net_pol.get("abuseipdb_tier2_penalty", 0.35))
    tier3_min  = int(net_pol.get("abuseipdb_tier3_min",  85))
    tier3_pen  = float(net_pol.get("abuseipdb_tier3_penalty", 0.60))

    if api_key and not _is_private_ip(ip):
        # Utilise le score pré-chargé si disponible, sinon le récupère
        if abuse_score is None:
            logger.debug(
                f"_score_network: no pre-fetched AbuseIPDB score — "
                f"fetching for {ip}"
            )
            abuse_score = _check_abuseipdb(ip, api_key)
        else:
            logger.debug(
                f"_score_network: using pre-fetched AbuseIPDB score "
                f"{abuse_score}/100 for {ip}"
            )
        if abuse_score is not None and abuse_score < hard_deny:
            if abuse_score >= tier3_min:
                score  -= tier3_pen
                parts.append(
                    f"AbuseIPDB tier 3 — high suspicion score {abuse_score}/100 "
                    f"(-{tier3_pen})"
                )
                logger.warning(
                    f"_score_network: AbuseIPDB TIER 3 penalty -{tier3_pen} "
                    f"for {ip} (score={abuse_score}, tier3_min={tier3_min})"
                )
            elif abuse_score >= tier2_min:
                score  -= tier2_pen
                parts.append(
                    f"AbuseIPDB tier 2 — moderate-high suspicion score {abuse_score}/100 "
                    f"(-{tier2_pen})"
                )
                logger.warning(
                    f"_score_network: AbuseIPDB TIER 2 penalty -{tier2_pen} "
                    f"for {ip} (score={abuse_score}, tier2_min={tier2_min})"
                )
            elif abuse_score >= tier1_min:
                score  -= tier1_pen
                parts.append(
                    f"AbuseIPDB tier 1 — low-moderate suspicion score {abuse_score}/100 "
                    f"(-{tier1_pen})"
                )
                logger.info(
                    f"_score_network: AbuseIPDB TIER 1 penalty -{tier1_pen} "
                    f"for {ip} (score={abuse_score}, tier1_min={tier1_min})"
                )
            else:
                parts.append(
                    f"AbuseIPDB score {abuse_score}/100 — below tier 1 threshold, "
                    f"no penalty"
                )
                logger.debug(
                    f"_score_network: AbuseIPDB score {abuse_score} for {ip} "
                    f"below tier 1 min {tier1_min} — no penalty"
                )

    final_score = round(max(0.0, min(1.0, score)), 4)
    logger.info(
        f"_score_network: FINAL network score={final_score} for {ip} | "
        + " | ".join(parts)
    )
    return final_score, " | ".join(parts)


def _score_behavioural(user_id, pol):
    """
    0.10 weight.
    Score based on time-of-access and historical access pattern.
    """
    time_pol = pol.get("time_policy", {})
    parts    = []
    score    = 1.0

    # Time-of-access
    try:
        now      = datetime.utcnow()
        s_str    = time_pol.get("normal_period_start", "07:00:00")
        e_str    = time_pol.get("normal_period_end",   "19:00:00")
        s_sec = _parse_time_str(s_str)
        e_sec = _parse_time_str(e_str)
        n_sec = now.hour*3600 + now.minute*60 + now.second

        if s_sec <= n_sec <= e_sec:
            parts.append(f"Within normal hours {s_str}–{e_str} UTC")
        else:
            pen = float(time_pol.get("out_of_hours_penalty", 0.20))
            score -= pen
            parts.append(
                f"Outside normal hours ({now.strftime('%H:%M')} UTC) (-{pen})"
            )
    except Exception as e:
        logger.warning(f"Time check error: {e}")
        parts.append("Time check unavailable")

    # Sign-in risk
    if user_id:
        risk      = get_risk_score(user_id)
        threshold = float(pol.get("network_policy", {})
                          .get("sign_in_risk_threshold", 0.40))
        if risk >= threshold:
            penalty = min(risk * 0.40, 0.40)
            score  -= penalty
            parts.append(
                f"High sign-in risk score {risk:.2f} "
                f"(threshold {threshold}) (-{penalty:.2f})"
            )
        elif risk > 0.15:
            score -= 0.05
            parts.append(f"Elevated sign-in risk {risk:.2f} (-0.05)")
        else:
            parts.append(f"Low sign-in risk {risk:.2f}")

        # Historical access pattern
        history   = get_user_history(user_id)
        if history:
            total     = len(history)
            successes = sum(1 for e in history if e.get("success", False))
            rate      = successes / total
            if rate >= 0.85:
                parts.append(f"Strong access history: {successes}/{total} successful")
            elif rate >= 0.60:
                score -= 0.05
                parts.append(f"Mixed access history: {successes}/{total} successful (-0.05)")
            else:
                score -= 0.15
                parts.append(f"Poor access history: {successes}/{total} successful (-0.15)")
        else:
            score -= 0.05
            parts.append("No prior access history — first access (-0.05)")

    return round(max(0.0, min(1.0, score)), 4), " | ".join(parts)


# ── User-Agent parser ─────────────────────────────────────────

def _parse_user_agent(ua: str) -> dict:
    """
    Parse the User-Agent string into structured device information.
    Returns OS name, OS version, browser name, browser version,
    and device type (desktop/mobile/tablet/headless/unknown).
    """
    if not ua or ua in ("-", ""):
        return {
            "raw":             ua,
            "device_type":     "unknown",
            "os":              "unknown",
            "os_version":      "",
            "browser":         "unknown",
            "browser_version": "",
        }

    ua_lower = ua.lower()

    # Device type
    if any(k in ua_lower for k in ["curl", "wget", "python", "go-http",
                                    "java/", "libwww", "scrapy", "bot",
                                    "spider", "crawl", "headless"]):
        device_type = "headless"
    elif "ipad" in ua_lower or "tablet" in ua_lower:
        device_type = "tablet"
    elif any(k in ua_lower for k in ["iphone", "android", "mobile",
                                      "blackberry", "windows phone"]):
        device_type = "mobile"
    else:
        device_type = "desktop"

    # OS detection
    os_name    = "unknown"
    os_version = ""

    if "windows nt" in ua_lower:
        os_name = "Windows"
        m = re.search(r"windows nt ([\d.]+)", ua_lower)
        nt_map = {
            "10.0": "10/11", "6.3": "8.1", "6.2": "8",
            "6.1": "7", "6.0": "Vista", "5.1": "XP"
        }
        if m:
            os_version = nt_map.get(m.group(1), m.group(1))
    elif "mac os x" in ua_lower or "macos" in ua_lower:
        os_name = "macOS"
        m = re.search(r"mac os x ([\d_]+)", ua_lower)
        if m:
            os_version = m.group(1).replace("_", ".")
    elif "iphone os" in ua_lower:
        os_name = "iOS"
        m = re.search(r"iphone os ([\d_]+)", ua_lower)
        if m:
            os_version = m.group(1).replace("_", ".")
    elif "android" in ua_lower:
        os_name = "Android"
        m = re.search(r"android ([\d.]+)", ua_lower)
        if m:
            os_version = m.group(1)
    elif "ubuntu" in ua_lower:
        os_name = "Ubuntu"
    elif "debian" in ua_lower:
        os_name = "Debian"
    elif "kali" in ua_lower:
        os_name = "Kali"
    elif "linux" in ua_lower:
        os_name = "Linux"

    # Browser detection — order matters (check Edge before Chrome)
    browser      = "unknown"
    browser_ver  = ""

    if "edg/" in ua_lower or "edge/" in ua_lower:
        browser = "Edge"
        m = re.search(r"edg[e]?/([\d.]+)", ua_lower)
        if m:
            browser_ver = m.group(1).split(".")[0]
    elif "opr/" in ua_lower or "opera" in ua_lower:
        browser = "Opera"
        m = re.search(r"opr/([\d.]+)", ua_lower)
        if m:
            browser_ver = m.group(1).split(".")[0]
    elif "firefox/" in ua_lower:
        browser = "Firefox"
        m = re.search(r"firefox/([\d.]+)", ua_lower)
        if m:
            browser_ver = m.group(1).split(".")[0]
    elif "chrome/" in ua_lower:
        browser = "Chrome"
        m = re.search(r"chrome/([\d.]+)", ua_lower)
        if m:
            browser_ver = m.group(1).split(".")[0]
    elif "safari/" in ua_lower and "chrome" not in ua_lower:
        browser = "Safari"
        m = re.search(r"version/([\d.]+)", ua_lower)
        if m:
            browser_ver = m.group(1).split(".")[0]

    return {
        "raw":             ua[:120],   # truncate for logging
        "device_type":     device_type,
        "os":              os_name,
        "os_version":      os_version,
        "browser":         browser,
        "browser_version": browser_ver,
    }


# ── IP helpers ────────────────────────────────────────────────

def _is_private_ip(ip: str) -> bool:
    private = (
        "10.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
        "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.",
        "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
        "192.168.", "127.", "::1", "0:0:0:0",
    )
    return any(ip.startswith(p) for p in private)


def _get_ip_info(ip: str) -> dict:
    """Fetch org and country from ipinfo.io."""
    try:
        r = requests.get(f"https://ipinfo.io/{ip}/json/", timeout=3)
        if r.status_code == 200:
            data = r.json()
            logger.debug(f"_get_ip_info: raw response for {ip} = {data}")
            return data
        else:
            logger.warning(
                f"_get_ip_info: ipinfo.io returned HTTP {r.status_code} "
                f"for {ip}"
            )
    except requests.exceptions.Timeout:
        logger.warning(f"_get_ip_info: timeout querying ipinfo.io for {ip}")
    except requests.exceptions.ConnectionError:
        logger.warning(
            f"_get_ip_info: cannot reach ipinfo.io — "
            f"Trust Engine host may not have internet access"
        )
    except Exception as e:
        logger.warning(f"_get_ip_info: unexpected error for {ip}: {e}")
    return {}


def _check_abuseipdb(ip: str, api_key: str) -> int | None:
    """
    Query AbuseIPDB for the IP's abuse confidence score.
    Returns 0-100 or None if the query fails.
    """
    logger.debug(
        f"_check_abuseipdb: calling AbuseIPDB API for {ip} "
        f"(key={api_key[:8]}...)"
    )
    try:
        r = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": api_key, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": 90},
            timeout=3,
        )
        logger.debug(
            f"_check_abuseipdb: HTTP {r.status_code} for {ip}"
        )
        if r.status_code == 200:
            data  = r.json().get("data", {})
            score = data.get("abuseConfidenceScore", 0)
            logger.debug(
                f"_check_abuseipdb: raw response for {ip} — "
                f"score={score} "
                f"domain='{data.get('domain','?')}' "
                f"usageType='{data.get('usageType','?')}' "
                f"countryCode='{data.get('countryCode','?')}' "
                f"totalReports={data.get('totalReports','?')} "
                f"lastReportedAt='{data.get('lastReportedAt','?')}'"
            )
            return score
        elif r.status_code == 401:
            logger.error(
                f"_check_abuseipdb: 401 Unauthorised — "
                f"API key is invalid or expired"
            )
        elif r.status_code == 422:
            logger.error(
                f"_check_abuseipdb: 422 Unprocessable — "
                f"IP address {ip!r} was rejected by AbuseIPDB"
            )
        elif r.status_code == 429:
            logger.warning(
                f"_check_abuseipdb: 429 Rate limit exceeded — "
                f"reduce request frequency or upgrade API plan"
            )
        else:
            logger.warning(
                f"_check_abuseipdb: unexpected HTTP {r.status_code} "
                f"for {ip}: {r.text[:200]}"
            )
    except requests.exceptions.Timeout:
        logger.warning(
            f"_check_abuseipdb: timeout querying AbuseIPDB for {ip}"
        )
    except requests.exceptions.ConnectionError:
        logger.warning(
            f"_check_abuseipdb: cannot reach api.abuseipdb.com — "
            f"check internet connectivity"
        )
    except Exception as e:
        logger.warning(f"_check_abuseipdb: unexpected error for {ip}: {e}")
    return None


if __name__ == "__main__":
    logger.info("Starting Trust Engine on port 5001...")
    app.run(host="0.0.0.0", port=5001, debug=True)
