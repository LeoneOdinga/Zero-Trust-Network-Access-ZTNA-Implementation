# ─────────────────────────────────────────────────────────────
# policy_engine_service.py
# Moteur de politiques — port 5002
#
# Évalue les demandes d'accès selon policies.yaml :
#   1. Vérification de refus total (transmis par le moteur de confiance)
#   2. Existence de la ressource
#   3. Rôle autorisé pour cette ressource
#   4. Restriction horaire par rôle
#   5. Restriction de type d'appareil
#   6. Score de confiance suffisant (surcharge par rôle si définie)
#
# Démarrage : python policy_engine_service.py
# ─────────────────────────────────────────────────────────────

import logging
import os
import yaml
from datetime import datetime
from flask import Flask, request, jsonify

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [POLICY ENGINE] [%(levelname)s] %(message)s"
)
logger      = logging.getLogger(__name__)
app         = Flask(__name__)
POLICY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policies.yaml")


def _load_policies() -> dict:
    with open(POLICY_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _deny(reason: str, rule: str = "") -> dict:
    return {
        "decision":     "DENY",
        "access_level": None,
        "reason":       reason,
        "rule":         rule,
        "connection":   None,
    }



def _parse_time_str(t: str) -> int:
    """
    Parse a time string into total seconds since midnight.
    Handles HH:MM, HH:MM:SS, and malformed HH:MM:SS:00 gracefully.
    Only the first three parts (H, M, S) are used.
    """
    parts = str(t).strip().split(":")
    h = int(parts[0]) if len(parts) > 0 else 0
    m = int(parts[1]) if len(parts) > 1 else 0
    s = int(parts[2]) if len(parts) > 2 else 0
    return h * 3600 + m * 60 + s

# ── Santé ────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"service": "policy_engine", "status": "online", "port": 5002}), 200


# ── Décision ─────────────────────────────────────────────────

@app.route("/decision", methods=["POST"])
def decision():
    """
    Expected JSON:
    {
        "user_roles":   list[str],
        "resource_id":  str,
        "trust_score":  int,
        "breakdown":    dict,
        "device_info":  dict,
        "deny_reason":  str | null
    }
    Returns:
    {
        "decision":     "GRANT" | "DENY",
        "access_level": str | null,
        "reason":       str,
        "rule":         str,
        "connection":   { host, port, protocol, duration } | null
    }
    """
    d = request.get_json(silent=True)
    if not d:
        return jsonify({"error": "Missing JSON body"}), 400

    user_roles  = d.get("user_roles",  [])
    resource_id = d.get("resource_id", "")
    trust_score = d.get("trust_score", 0)
    breakdown   = d.get("breakdown",  {})
    device_info = d.get("device_info", {})
    deny_reason = d.get("deny_reason", None)

    logger.info(
        f"Decision: roles={user_roles} resource='{resource_id}' "
        f"score={trust_score}"
    )

    try:
        pol = _load_policies()
    except Exception as e:
        logger.error(f"Policy load failed: {e}")
        return jsonify(_deny("Policy Engine could not load policies.")), 503

    # ── Vérification 1 : refus total transmis par le moteur de confiance
    if deny_reason:
        logger.warning(f"Hard deny from Trust Engine: {deny_reason}")
        return jsonify(_deny(deny_reason, rule="HARD_DENY")), 200

    # ── Vérification 2 : existence de la ressource ───────────────
    resources = pol.get("resources", {})
    if resource_id not in resources:
        return jsonify(
            _deny(
                f"Resource '{resource_id}' is not defined in policy.",
                rule="UNKNOWN_RESOURCE"
            )
        ), 200

    res_pol  = resources[resource_id]
    name     = res_pol.get("display_name", resource_id)
    permitted = res_pol.get("roles", {})

    # ── Check 3: Role permitted — pick highest-privilege match ──
    # Un utilisateur peut avoir plusieurs rôles. On collecte TOUS les rôles
    # correspondants et on sélectionne celui qui accorde le niveau d'accès le plus élevé.
    # Priorité : FULL_ACCESS > READ_ONLY
    ACCESS_PRIORITY = {"FULL_ACCESS": 2, "READ_ONLY": 1}

    matching_roles = {r: permitted[r] for r in user_roles if r in permitted}
    if not matching_roles:
        return jsonify(_deny(
            f"None of your roles {user_roles} have permission to access "
            f"{name}. Permitted roles: {list(permitted.keys())}.",
            rule="ROLE_NOT_PERMITTED"
        )), 200

    # Sélection du rôle accordant le niveau d'accès le plus élevé
    matched_role = max(
        matching_roles,
        key=lambda r: ACCESS_PRIORITY.get(
            matching_roles[r].get("access_level", "READ_ONLY"), 0
        )
    )
    role_config = matching_roles[matched_role]

    if len(matching_roles) > 1:
        logger.info(
            f"policy_engine: user holds {list(matching_roles.keys())} — "
            f"selected '{matched_role}' "
            f"(access_level={role_config.get('access_level')})"
        )

    # ── Vérification 4 : restriction horaire ─────────────────────
    time_pol = pol.get("time_policy", {})
    time_deny = _check_time_restriction(matched_role, time_pol)
    if time_deny:
        return jsonify(_deny(time_deny, rule="TIME_RESTRICTION")), 200

    # ── Vérification 5 : restriction type d'appareil ────────────
    dev_pol     = pol.get("device_policy", {})
    device_type = device_info.get("device_type", "unknown")
    blocked_devices = [d.lower() for d in dev_pol.get("blocked_device_types", [])]

    if device_type.lower() in blocked_devices:
        return jsonify(_deny(
            f"Device type '{device_type}' is not permitted for "
            f"resource access. Use a trusted desktop or tablet.",
            rule="DEVICE_BLOCKED"
        )), 200

    # ── Vérification 6 : score de confiance suffisant ────────────
    # Utilise la surcharge spécifique au rôle si définie, sinon la valeur par défaut
    min_score = int(
        role_config.get("min_trust_score_override")
        or res_pol.get("min_trust_score", 70)
    )

    if trust_score < min_score:
        weak = [
            k for k, v in breakdown.items()
            if isinstance(v, dict) and v.get("score", 1) < 0.60
        ]
        hint   = f" Weak signals: {', '.join(weak)}." if weak else ""
        return jsonify(_deny(
            f"Trust score {trust_score}/100 is below the required "
            f"{min_score}/100 for {name} with role '{matched_role}'.{hint}",
            rule="SCORE_BELOW_THRESHOLD"
        )), 200

    # ── GRANT (subject to dynamic rule evaluation) ────────────
    access_level = role_config.get("access_level", "READ_ONLY")
    duration     = int(
        role_config.get("session_duration_override")
        or res_pol.get("session_duration_minutes", 30)
    )

    # Évalue les règles de politique dynamiques avant de finaliser l'accord
    rule_verdict = _evaluate_policy_rules(
        pol          = pol,
        trust_score  = trust_score,
        breakdown    = breakdown,
        device_info  = device_info,
        user_roles   = user_roles,
        resource_id  = resource_id,
        access_level = access_level,
    )

    if rule_verdict["action"] == "DENY":
        logger.info(
            f"DENY (rule '{rule_verdict['rule_id']}' '{rule_verdict['rule_name']}'): "
            f"role='{matched_role}' resource='{resource_id}' score={trust_score}"
        )
        return jsonify(_deny(rule_verdict["reason"],
                             rule=rule_verdict["rule_id"])), 200

    if rule_verdict["action"] == "ALLOW_READ_ONLY":
        access_level = "READ_ONLY"
        logger.info(
            f"DOWNGRADE to READ_ONLY (rule '{rule_verdict['rule_id']}' "
            f"'{rule_verdict['rule_name']}'): role='{matched_role}' "
            f"resource='{resource_id}' score={trust_score}"
        )

    logger.info(
        f"GRANT: role='{matched_role}' resource='{resource_id}' "
        f"level='{access_level}' score={trust_score} duration={duration}min"
    )

    return jsonify({
        "decision":     "GRANT",
        "access_level": access_level,
        "rule":         "GRANTED",
        "reason": (
            f"Access granted to {name} as {matched_role}. "
            f"Session valid for {duration} minutes."
        ),
        "connection": {
            "host":     res_pol.get("host"),
            "port":     res_pol.get("port"),
            "protocol": res_pol.get("protocol"),
            "duration": duration,
        }
    }), 200



# ── Évaluateur de règles de politique dynamiques ────────────

def _evaluate_policy_rules(
    pol:          dict,
    trust_score:  int,
    breakdown:    dict,
    device_info:  dict,
    user_roles:   list,
    resource_id:  str,
    access_level: str,
) -> dict:
    """
    Evaluate all enabled policy_rules from policies.yaml in priority order.
    Returns the first matching rule's verdict, or CONTINUE if no rule fires.

    Return structure:
      { action: DENY|ALLOW_READ_ONLY|ALLOW_FULL|CONTINUE,
        rule_id, rule_name, reason }
    """
    rules = pol.get("policy_rules", [])
    if not rules:
        return {"action": "CONTINUE", "rule_id": None, "rule_name": None, "reason": None}

    # Tri par priorité (numéro le plus bas = priorité la plus haute)
    enabled = [r for r in rules if r.get("enabled", True)]
    enabled.sort(key=lambda r: r.get("priority", 999))

    # Construction du dictionnaire de contexte interrogeable par les conditions
    def get_breakdown_score(signal: str) -> float:
        sig = breakdown.get(signal, {})
        if isinstance(sig, dict):
            return float(sig.get("score", 1.0))
        return 1.0

    # Vérification horaire (réutilise time_policy)
    time_pol   = pol.get("time_policy", {})
    now_utc    = datetime.utcnow()
    s_sec = _parse_time_str(time_pol.get("normal_period_start", "07:00:00"))
    e_sec = _parse_time_str(time_pol.get("normal_period_end",   "19:00:00"))
    n_sec = now_utc.hour * 3600 + now_utc.minute * 60 + now_utc.second
    within_hours = s_sec <= n_sec <= e_sec

    # Signaux d'appareil depuis device_info (télémétrie dans breakdown.device.detail)
    dev_detail = ""
    if isinstance(breakdown.get("device"), dict):
        dev_detail = breakdown["device"].get("detail", "")

    ctx = {
        # Scores des signaux de confiance
        "trust_score":        trust_score,
        "device_score":       round(get_breakdown_score("device") * 100),
        "identity_score":     round(get_breakdown_score("identity") * 100),
        "network_score":      round(get_breakdown_score("network") * 100),
        "auth_score":         round(get_breakdown_score("authentication") * 100),
        "behavioural_score":  get_breakdown_score("behavioural"),
        # Identité
        "role":               user_roles,
        "resource":           resource_id,
        "access_level":       access_level,
        # Signaux de l'agent d'appareil (renseignés depuis la télémétrie)
        "agent_status":       device_info.get("agent_status", "never"),
        "device_encrypted":   device_info.get("device_encrypted"),
        "firewall_enabled":   device_info.get("firewall_enabled"),
        "av_enabled":         device_info.get("av_enabled"),
        "realtime_av":        device_info.get("realtime_av"),
        "domain_joined":      device_info.get("domain_joined"),
        "ioc_detected":       device_info.get("ioc_detected"),
        "patch_days":         device_info.get("patch_days", -1),
        # Réseau
        "ip_type":            device_info.get("ip_type", "unknown"),
        # Horaire
        "time_of_day":        "within_hours" if within_hours else "outside_hours",
    }

    for rule in enabled:
        conditions = rule.get("conditions", [])
        logic      = rule.get("logic", "AND").upper()

        results = [_eval_condition(c, ctx) for c in conditions]

        if logic == "AND":
            matched = all(results)
        elif logic == "OR":
            matched = any(results)
        elif logic == "NOT":
            matched = not all(results)
        else:
            matched = all(results)

        if matched:
            action = rule.get("action", "CONTINUE")
            logger.info(
                f"_evaluate_policy_rules: rule '{rule.get('id')}' "
                f"'{rule.get('name')}' fired -> {action}"
            )
            return {
                "action":    action,
                "rule_id":   rule.get("id", ""),
                "rule_name": rule.get("name", ""),
                "reason":    rule.get("reason", f"Policy rule '{rule.get('name')}' applied."),
            }

    return {"action": "CONTINUE", "rule_id": None, "rule_name": None, "reason": None}


def _eval_condition(condition: dict, ctx: dict) -> bool:
    """
    Evaluate a single condition against the request context.
    Returns True if the condition is satisfied.
    """
    attr  = condition.get("attribute", "")
    op    = condition.get("operator", "eq").lower()
    value = condition.get("value")

    ctx_val = ctx.get(attr)
    if ctx_val is None:
        return False

    try:
        # Comparaisons numériques
        if op == "gt":  return float(ctx_val) >  float(value)
        if op == "gte": return float(ctx_val) >= float(value)
        if op == "lt":  return float(ctx_val) <  float(value)
        if op == "lte": return float(ctx_val) <= float(value)

        # Égalité
        if op == "eq":
            if isinstance(value, bool) or value in (True, False, "true", "false"):
                bval = value if isinstance(value, bool) else value == "true"
                return bool(ctx_val) == bval
            return str(ctx_val).lower() == str(value).lower()

        if op == "neq":
            return str(ctx_val).lower() != str(value).lower()

        # Appartenance à une liste
        if op == "in":
            if isinstance(ctx_val, list):
                val_lower = [str(v).lower() for v in value] if isinstance(value, list) else [str(value).lower()]
                return any(str(cv).lower() in val_lower for cv in ctx_val)
            val_lower = [str(v).lower() for v in value] if isinstance(value, list) else [str(value).lower()]
            return str(ctx_val).lower() in val_lower

        if op == "not_in":
            if isinstance(ctx_val, list):
                val_lower = [str(v).lower() for v in value] if isinstance(value, list) else [str(value).lower()]
                return not any(str(cv).lower() in val_lower for cv in ctx_val)
            val_lower = [str(v).lower() for v in value] if isinstance(value, list) else [str(value).lower()]
            return str(ctx_val).lower() not in val_lower

    except (TypeError, ValueError) as e:
        logger.warning(f"_eval_condition: error evaluating {attr} {op} {value}: {e}")

    return False


# ── Time restriction checker ──────────────────────────────────

def _check_time_restriction(role: str, time_pol: dict) -> str | None:
    """
    Returns a denial reason if the role is not permitted to access
    resources at the current time. Returns None if access is allowed.
    """
    try:
        now   = datetime.utcnow()
        s_str = time_pol.get("normal_period_start", "07:00:00")
        e_str = time_pol.get("normal_period_end",   "19:00:00")
        s_sec = _parse_time_str(s_str)
        e_sec = _parse_time_str(e_str)
        n_sec = now.hour*3600 + now.minute*60 + now.second

        # Dans les horaires normaux — toujours autorisé
        if s_sec <= n_sec <= e_sec:
            return None

        # En dehors des horaires normaux
        blocked_roles = time_pol.get("blocked_outside_hours_roles", [])
        if role in blocked_roles:
            return (
                f"Role '{role}' is not permitted to access resources outside "
                f"normal hours ({s_str}–{e_str} UTC). "
                f"Current time: {now.strftime('%H:%M')} UTC."
            )

        # Les rôles avec horaires étendus ont accès mais avec pénalité réduite
        extended_roles = time_pol.get("extended_hours_roles", [])
        if role in extended_roles:
            logger.info(
                f"policy_engine: role '{role}' has extended hours access — "
                f"access granted with reduced trust penalty"
            )
            return None

        # Tous les autres rôles — autorisés mais pénalité hors horaires appliquée
        return None

    except Exception as e:
        logger.warning(f"Time restriction check failed: {e}")
        return None


if __name__ == "__main__":
    logger.info("Starting Policy Engine on port 5002...")
    app.run(host="0.0.0.0", port=5002, debug=True)
