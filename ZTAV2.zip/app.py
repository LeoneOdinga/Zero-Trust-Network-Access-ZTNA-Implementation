# ─────────────────────────────────────────────────────────────
# app.py  —  Portail Zéro Confiance  —  Port 5000
# ─────────────────────────────────────────────────────────────

import datetime
import logging
import os

import requests as http_requests
import yaml

from flask import (
    Flask, render_template, request, jsonify,
    session, url_for, redirect, make_response
)
from flask_oidc import OpenIDConnect
from keycloak import KeycloakOpenID, KeycloakAuthenticationError

from keycloak_config import (
    SERVER_URL, KEYCLOAK_REALM,
    KEYCLOAK_CLIENT_ID, KEYCLOAK_CLIENT_SECRET,
    REVOCATION_URL,
)
from keycloak_functions import token_is_valid, extract_user_role, revoke_token
from service_client    import call_trust_engine, call_policy_engine, check_services
from signin_tracker    import (
    record_login_success,
    record_login_failure,
    get_all_login_stats,
    get_login_stats,
    get_risk_score,
)
from mysql_broker import provision_access as mysql_provision_access
from ssh_broker   import provision_access as ssh_provision_access

# ── Journalisation ───────────────────────────────────────────

logging.basicConfig(
    level  = logging.DEBUG,
    format = "%(asctime)s [PORTAL] [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)

# ── Flask ────────────────────────────────────────────────────

app = Flask(__name__)
app.config.update(
    SECRET_KEY                     = "bzf9bctfGor9tB2rOfLdQnK3VNDxt6rx",
    TESTING                        = True,
    DEBUG                          = True,
    OIDC_SESSION_TYPE              = "null",
    OIDC_CLIENT_SECRETS            = "client_secrets.json",
    OIDC_ID_TOKEN_COOKIE_SECURE    = False,
    OIDC_USER_INFO_ENABLED         = True,
    OIDC_OPENID_REALM              = KEYCLOAK_REALM,
    OIDC_SCOPES                    = ["openid", "email", "profile"],
    OIDC_TOKEN_TYPE_HINT           = "access_token",
    OIDC_INTROSPECTION_AUTH_METHOD = "client_secret_post",
)

oidc = OpenIDConnect(app)

keycloak_openid = KeycloakOpenID(
    server_url        = SERVER_URL,
    client_id         = KEYCLOAK_CLIENT_ID,
    realm_name        = KEYCLOAK_REALM,
    client_secret_key = KEYCLOAK_CLIENT_SECRET,
)

# ── Administration Keycloak — HTTP direct ────────────────────

KEYCLOAK_ADMIN_USER     = "sir"
KEYCLOAK_ADMIN_PASSWORD = "admin"

_KC_TOKEN_URL  = f"{SERVER_URL.rstrip('/')}/realms/master/protocol/openid-connect/token"
_KC_EVENTS_URL = f"{SERVER_URL.rstrip('/')}/admin/realms/{KEYCLOAK_REALM}/events"


def _get_admin_token() -> str | None:
    for payload in [
        {"grant_type": "password", "client_id": "admin-cli",
         "username": KEYCLOAK_ADMIN_USER, "password": KEYCLOAK_ADMIN_PASSWORD},
        {"grant_type": "password", "client_id": "admin-cli", "client_secret": "",
         "username": KEYCLOAK_ADMIN_USER, "password": KEYCLOAK_ADMIN_PASSWORD},
    ]:
        try:
            r = http_requests.post(_KC_TOKEN_URL, data=payload, timeout=8, verify=False)
            if r.status_code == 200:
                return r.json().get("access_token")
            logger.warning(f"_get_admin_token: HTTP {r.status_code} — {r.json().get('error_description','')}")
        except Exception as e:
            logger.warning(f"_get_admin_token: {e}")
    return None


def _sync_all_users(admin_token: str) -> tuple[int, int]:
    """
    Fetch ALL LOGIN and LOGIN_ERROR events from Keycloak for all
    users and record any not yet stored locally.

    Two separate requests are made:
      - type=LOGIN       → records successes for all users
      - type=LOGIN_ERROR → records failures for all users

    Dedup is set-based inside record_login_success/failure —
    safe to call on every dashboard poll, no duplicates possible.

    Returns (new_successes, new_failures).
    """
    headers    = {"Authorization": f"Bearer {admin_token}"}
    new_succ   = 0
    new_fail   = 0

    # ── Succès ───────────────────────────────────────────────────
    try:
        r = http_requests.get(
            _KC_EVENTS_URL, headers=headers,
            params={"max": 100, "type": "LOGIN"},
            timeout=8, verify=False,
        )
        if r.status_code == 200:
            events = r.json()
            logger.info(f"_sync_all: {len(events)} LOGIN event(s) from Keycloak")
            for ev in events:
                ev_uid = (ev.get("userId") or "").strip()
                if not ev_uid:
                    continue
                details = ev.get("details") or {}
                wrote = record_login_success(
                    user_id    = ev_uid,
                    ip_address = ev.get("ipAddress", ""),
                    username   = details.get("username", ""),
                    kc_time_ms = ev.get("time", 0),
                )
                if wrote:
                    new_succ += 1
        else:
            logger.warning(f"_sync_all: LOGIN fetch HTTP {r.status_code}")
    except Exception as e:
        logger.warning(f"_sync_all: LOGIN fetch exception — {e}")

    # ── Échecs ───────────────────────────────────────────────────
    try:
        r = http_requests.get(
            _KC_EVENTS_URL, headers=headers,
            params={"max": 100, "type": "LOGIN_ERROR"},
            timeout=8, verify=False,
        )
        if r.status_code == 200:
            events = r.json()
            logger.info(f"_sync_all: {len(events)} LOGIN_ERROR event(s) from Keycloak")
            for ev in events:
                ev_uid = (ev.get("userId") or "").strip()
                if not ev_uid:
                    continue
                details = ev.get("details") or {}
                wrote = record_login_failure(
                    user_id    = ev_uid,
                    ip_address = ev.get("ipAddress", ""),
                    username   = details.get("username", ""),
                    error      = ev.get("error", ""),
                    kc_time_ms = ev.get("time", 0),
                )
                if wrote:
                    new_fail += 1
        else:
            logger.warning(f"_sync_all: LOGIN_ERROR fetch HTTP {r.status_code}")
    except Exception as e:
        logger.warning(f"_sync_all: LOGIN_ERROR fetch exception — {e}")

    if new_succ or new_fail:
        logger.info(
            f"_sync_all: recorded {new_succ} new success(es) "
            f"and {new_fail} new failure(s) across all users"
        )
    return new_succ, new_fail


def _sync_all_users_failures() -> int:
    """Wrapper called from api_monitoring — syncs both LOGIN and LOGIN_ERROR."""
    admin_token = _get_admin_token()
    if not admin_token:
        logger.warning("_sync_all: could not get admin token")
        return 0
    new_succ, new_fail = _sync_all_users(admin_token)
    return new_succ + new_fail


def _sync_failures(user_id: str, current_uname: str) -> int:
    """Per-user sync called from /home — delegates to global sync."""
    return _sync_all_users_failures()



# ── Fichier de politique ─────────────────────────────────────

POLICY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policies.yaml")
if not os.path.exists(POLICY_FILE):
    raise FileNotFoundError(f"policies.yaml not found at {POLICY_FILE}")


def _is_private_ip(ip: str) -> bool:
    """Return True if the IP is a private / loopback / link-local address."""
    private_prefixes = (
        "10.", "127.", "169.254.",
        "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
        "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
        "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
        "192.168.", "::1", "fc", "fd",
    )
    return any(ip.startswith(p) for p in private_prefixes)


def _resolve_public_ip(browser_ip: str | None, server_ip: str) -> str:
    """
    Determine the best public IP to use for network trust scoring.

    Priority:
      1. Browser-reported IP (from ipify client-side) — if valid and public
      2. Server-side ipify fetch — if browser IP is absent or private
      3. server_ip fallback — if both ipify calls fail (no internet)

    This ensures geolocation and AbuseIPDB scoring work even when
    the portal sits on a private LAN.
    """
    # Utilise l'IP rapportée par le navigateur si c'est une IP publique valide
    if browser_ip and not _is_private_ip(browser_ip):
        logger.info(
            f"_resolve_public_ip: using browser-reported IP {browser_ip}"
        )
        return browser_ip

    # IP navigateur absente ou privée — tentative ipify côté serveur
    logger.debug(
        f"_resolve_public_ip: browser IP {browser_ip!r} unusable — "
        f"querying ipify server-side"
    )
    try:
        import requests as _req
        r = _req.get(
            "https://api.ipify.org?format=json",
            timeout=4,
            headers={"User-Agent": "ZT-Portal/1.0"}
        )
        if r.status_code == 200:
            public_ip = r.json().get("ip", "").strip()
            if public_ip and not _is_private_ip(public_ip):
                logger.info(
                    f"_resolve_public_ip: server-side ipify returned {public_ip}"
                )
                return public_ip
            else:
                logger.warning(
                    f"_resolve_public_ip: ipify returned non-public IP "
                    f"{public_ip!r} — falling back to server_ip"
                )
    except Exception as e:
        logger.warning(
            f"_resolve_public_ip: server-side ipify failed ({e}) — "
            f"falling back to server_ip {server_ip}"
        )

    logger.info(
        f"_resolve_public_ip: using server_ip {server_ip} "
        f"(all public IP resolution failed)"
    )
    return server_ip


def _load_policies():
    with open(POLICY_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _save_policies(data):
    with open(POLICY_FILE, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)


# ═══════════════════════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════════════════════

@app.route("/")
@oidc.require_login
def index():
    if oidc.user_loggedin and token_is_valid(oidc, keycloak_openid):
        return redirect(url_for("home"))
    return render_template("index.html")


# ── Connexion — succès enregistré ici, échecs synchronisés ────

@app.route("/login")
@oidc.require_login
def login():
    if not token_is_valid(oidc, keycloak_openid):
        return render_template("index.html")

    raw       = oidc.get_access_token()
    token_str = raw["access_token"] if isinstance(raw, dict) else raw
    session["access_token"] = token_str

    auth_profile  = session.get("oidc_auth_profile", {})
    user_id       = auth_profile.get("sub", "")
    current_uname = (
        auth_profile.get("preferred_username", "") or
        auth_profile.get("email", "")
    ).lower().strip()

    if not user_id:
        try:
            user_id = keycloak_openid.introspect(token_str).get("sub", "")
        except Exception:
            pass

    if user_id:
        ip = request.headers.get(
            "X-Forwarded-For", request.remote_addr
        ).split(",")[0].strip()

        # 1. Enregistrement de la connexion réussie
        record_login_success(user_id=user_id, ip_address=ip, username=current_uname)

        # 2. Synchronisation des échecs précédents depuis Keycloak
        _sync_failures(user_id, current_uname)

        # 3. Résolution du device_id par IP — fonctionne quel que soit
        #    le nom d'utilisateur configuré sur la machine Windows.
        #    L'agent et le navigateur partagent la même IP sur le même hôte.
        device_id = _find_device_id_for_ip(ip)
        if device_id:
            session["device_id"] = device_id
            logger.info(
                f"login: device resolved for user={user_id[:8]}... "
                f"device_id={device_id} ip={ip}"
            )
        else:
            session.pop("device_id", None)
            logger.info(
                f"login: no device found for ip={ip} — "
                f"agent not running or heartbeat stale"
            )

    response = make_response(redirect(url_for("home")))
    response.set_cookie("access_token", token_str, httponly=True, samesite="Lax")
    return response


# ── Accueil ───────────────────────────────────────────────────

@app.route("/home")
def home():
    try:
        if not oidc.user_loggedin:
            return redirect(url_for("login"))
        if not token_is_valid(oidc, keycloak_openid):
            return render_template("error.html",
                message="Your session has expired."), 401
        auth_profile = session.get("oidc_auth_profile")
        if not auth_profile:
            return render_template("error.html",
                message="Authorisation profile not found."), 403
        user_roles = extract_user_role(oidc, keycloak_openid) or ["viewer"]
        return render_template("home.html",
            username   = auth_profile.get("name"),
            email      = auth_profile.get("email"),
            user_id    = auth_profile.get("sub"),
            user_roles = user_roles,
        )
    except KeycloakAuthenticationError as e:
        logger.error(f"home: {e}")
        return redirect(url_for("index"))


# ── Sélection de ressources ──────────────────────────────────

@app.route("/resource-selection")
def resource_selection():
    if not oidc.user_loggedin:
        return redirect(url_for("login"))
    if not token_is_valid(oidc, keycloak_openid):
        return render_template("error.html",
            message="Your session has expired."), 401
    auth_profile = session.get("oidc_auth_profile")
    if not auth_profile:
        return render_template("error.html",
            message="Authorisation profile not found."), 403
    user_roles = extract_user_role(oidc, keycloak_openid) or ["viewer"]
    return render_template("resource_selection.html",
        username   = auth_profile.get("name"),
        email      = auth_profile.get("email"),
        user_id    = auth_profile.get("sub"),
        user_roles = user_roles,
        config     = _load_policies(),
    )


# ── Demande d'accès ──────────────────────────────────────────

@app.route("/request-access", methods=["POST"])
def request_access():
    if not oidc.user_loggedin:
        return jsonify({"status": "denied", "message": "Not authenticated."}), 401
    if not token_is_valid(oidc, keycloak_openid):
        return jsonify({"status": "denied", "message": "Session expired."}), 401

    data = request.get_json(silent=True)
    if not data or "resource" not in data:
        return jsonify({"status": "denied", "message": "Resource identifier required."}), 400

    logger.debug(
        f"request_access: raw payload keys={list(data.keys())} "
        f"public_ip={data.get('public_ip')!r}"
    )

    resource_id  = data["resource"].strip().lower()
    user_roles   = extract_user_role(oidc, keycloak_openid) or ["viewer"]
    auth_profile = session.get("oidc_auth_profile", {})
    user_id      = auth_profile.get("sub",   "")
    user_email   = auth_profile.get("email", "unknown")
    server_ip    = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    user_agent   = request.headers.get("User-Agent", "")

    browser_public_ip = (data.get("public_ip") or "").strip()

    # Résolution de la meilleure IP publique disponible pour le scoring réseau.
    # _resolve_public_ip essaie d'abord l'IP du navigateur, puis ipify côté serveur,
    # sinon repli sur l'IP LAN (score 1.0 comme réseau de confiance).
    ip_address = _resolve_public_ip(browser_public_ip or None, server_ip)

    raw_token = oidc.get_access_token()
    token_iat = None
    if isinstance(raw_token, dict):
        token_iat = raw_token.get("iat")
    else:
        try:
            token_iat = keycloak_openid.introspect(raw_token).get("iat")
        except Exception:
            pass

    logger.info(
        f"request_access: user='{user_email}' roles={user_roles} "
        f"resource='{resource_id}' "
        f"server_ip={server_ip} network_ip={ip_address}"
    )

    try:
        trust_result = call_trust_engine(
            user_id=user_id, user_roles=user_roles, resource_id=resource_id,
            ip_address=ip_address, user_agent=user_agent,
            token_iat=token_iat, mfa_method=session.get("mfa_method"),
            device_id=_resolve_device_id(),
            public_ip=ip_address if not _is_private_ip(ip_address) else None,
        )
    except RuntimeError as e:
        logger.error(f"request_access: Trust Engine — {e}")
        return jsonify({"status": "denied", "message": str(e)}), 503

    trust_score = trust_result.get("trust_score", 0)
    breakdown   = trust_result.get("breakdown",   {})

    try:
        policy_result = call_policy_engine(
            user_roles=user_roles, resource_id=resource_id,
            trust_score=trust_score, breakdown=breakdown,
            device_info=trust_result.get("device_info", {}),
            deny_reason=trust_result.get("deny_reason"),
        )
    except RuntimeError as e:
        logger.error(f"request_access: Policy Engine — {e}")
        return jsonify({"status": "denied", "message": str(e)}), 503

    granted      = policy_result.get("decision") == "GRANT"
    access_level = policy_result.get("access_level")
    connection_details = policy_result.get("connection")

    if granted and resource_id == "mysql":
        try:
            duration = policy_result.get("connection", {}).get("duration", 30)
            connection_details = mysql_provision_access(
                user_id=user_id, access_level=access_level or "READ_ONLY",
                duration_minutes=duration,
                # Toujours utiliser l'IP LAN pour les règles UFW du courtier —
                # UFW opère au niveau réseau entre le portail et le serveur de ressources,
                # pas sur l'internet public. L'IP publique ne concerne que
                # le scoring réseau du moteur de confiance.
                client_ip=server_ip,
                device_id=session.get("device_id", ""),
                user_roles=user_roles, resource_id=resource_id,
            )
            logger.info(f"request_access: MySQL provisioned user='{connection_details['username']}'")
        except RuntimeError as e:
            logger.error(f"request_access: MySQL broker — {e}")
            return jsonify({"status": "denied", "message": str(e)}), 503

    elif granted and resource_id in ("linux-fs", "linux-server"):
        try:
            duration = policy_result.get("connection", {}).get("duration", 60)
            connection_details = ssh_provision_access(
                user_id=user_id, access_level=access_level or "READ_ONLY",
                duration_minutes=duration,
                # Toujours utiliser l'IP LAN pour les règles UFW du courtier.
                client_ip=server_ip,
                device_id=session.get("device_id", ""),
                user_roles=user_roles, resource_id=resource_id,
            )
            logger.info(f"request_access: SSH provisioned user='{connection_details['username']}'")
        except RuntimeError as e:
            logger.error(f"request_access: SSH broker — {e}")
            return jsonify({"status": "denied", "message": str(e)}), 503

    logger.info(f"request_access: {policy_result.get('decision')} user='{user_email}' resource='{resource_id}' score={trust_score}")

    if granted:
        return jsonify({
            "status": "granted", "trust_score": trust_score,
            "access_level": access_level,
            "message": policy_result.get("reason", "Access granted."),
            "connection": connection_details, "breakdown": breakdown,
        }), 200

    return jsonify({
        "status": "denied", "trust_score": trust_score,
        "message": policy_result.get("reason", "Access denied."),
        "breakdown": breakdown,
    }), 403


# ── Services health ───────────────────────────────────────────

@app.route("/services/health")
def services_health():
    if not oidc.user_loggedin:
        return jsonify({"error": "Unauthorised"}), 401
    return jsonify(check_services()), 200


# ── Logout ────────────────────────────────────────────────────

@app.route("/revokeToken")
@oidc.require_login
def revokeToken():
    try:
        refresh_token = oidc.get_refresh_token()
        if not refresh_token:
            return redirect(url_for("index"))
        success = revoke_token(
            client_id=KEYCLOAK_CLIENT_ID, client_secret=KEYCLOAK_CLIENT_SECRET,
            refresh_token=refresh_token, revocation_url=REVOCATION_URL,
        )
        if success:
            oidc.logout(); session.clear()
            resp = make_response(redirect(url_for("index")))
            resp.delete_cookie("access_token")
            return resp
        return render_template("error.html", message="Failed to revoke session."), 500
    except Exception as e:
        logger.error(f"revokeToken: {e}")
        return render_template("error.html", message="Logout error."), 500


# ── Policy configuration ──────────────────────────────────────

@app.route("/configurePolicies")
def configure_policies():
    if not oidc.user_loggedin:
        return redirect(url_for("login"))
    if not token_is_valid(oidc, keycloak_openid):
        return render_template("error.html", message="Session expired."), 401
    roles = extract_user_role(oidc, keycloak_openid)
    if not any(r in _policy_admin_roles() for r in roles):
        return render_template("error.html",
            message="You do not have permission to access Policy Configuration."), 403
    # Forcer l'absence de cache pour que le navigateur reçoive un rendu frais après sauvegarde
    from flask import make_response
    resp = make_response(
        render_template("policy_configuration.html", config=_load_policies())
    )
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"]        = "no-cache"
    resp.headers["Expires"]       = "0"
    return resp


@app.route("/receivePolicyConfigurations", methods=["POST"])
def receive_policy_configurations():
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorised"}), 401
    roles2 = extract_user_role(oidc, keycloak_openid) or []
    if not any(r in _policy_admin_roles() for r in roles2):
        return jsonify({"error": "Forbidden"}), 403
    incoming = request.get_json(silent=True)
    if not incoming:
        return jsonify({"error": "Missing JSON body"}), 400
    try:
        logger.info(
            f"receive_policy_configurations: incoming keys={list(incoming.keys())} "
            f"rules_count={len(incoming.get('policy_rules', []))}"
        )
        current = _load_policies()
        for key in ["trust_weights", "role_thresholds", "time_policy",
                    "device_policy", "network_policy", "device_trust_policy",
                    "access_control"]:
            if key in incoming:
                current.setdefault(key, {})
                current[key].update(incoming[key])

        # time_policy_roles est envoyé par l'UI comme clé séparée mais réside
        # dans time_policy dans policies.yaml — fusion correcte.
        if "time_policy_roles" in incoming:
            current.setdefault("time_policy", {})
            tpr = incoming["time_policy_roles"]
            if "extended" in tpr:
                current["time_policy"]["extended_hours_roles"] = tpr["extended"]
            if "blocked" in tpr:
                current["time_policy"]["blocked_outside_hours_roles"] = tpr["blocked"]

        for rid, dur in incoming.get("resource_durations", {}).items():
            if rid in current.get("resources", {}):
                current["resources"][rid]["session_duration_minutes"] = int(dur)

        # Sauvegarde des scores de confiance minimum par ressource
        for rid, score in incoming.get("resource_min_scores", {}).items():
            if rid in current.get("resources", {}):
                current["resources"][rid]["min_trust_score"] = int(score)
                logger.info(
                    f"receive_policy_configurations: "
                    f"resource '{rid}' min_trust_score set to {score}"
                )

        # Sauvegarde de la liste policy_rules (remplacement complet)
        if "policy_rules" in incoming:
            current["policy_rules"] = incoming["policy_rules"]

        # Sauvegarde des rôles avec horaires étendus/bloqués depuis l'UI
        if "time_policy_roles" in incoming:
            current.setdefault("time_policy", {})
            current["time_policy"]["extended_hours_roles"]      = incoming["time_policy_roles"].get("extended", [])
            current["time_policy"]["blocked_outside_hours_roles"] = incoming["time_policy_roles"].get("blocked", [])

        logger.info(f"receive_policy_configurations: saving to {POLICY_FILE}")
        _save_policies(current)
        # Vérification de l'écriture par relecture
        verify = _load_policies()
        saved_rules = len(verify.get("policy_rules", []))
        logger.info(
            f"receive_policy_configurations: SAVED OK — "
            f"rules={saved_rules} keys={list(verify.keys())}"
        )
        return jsonify({
            "status":   "ok",
            "message":  "Policies saved.",
            "saved_rules": saved_rules,
            "policy_file": POLICY_FILE,
        }), 200
    except Exception as e:
        logger.error(f"receive_policy_configurations: SAVE FAILED — {e}")
        return jsonify({"error": str(e)}), 500


# ── Monitoring ────────────────────────────────────────────────

def _get_access_control() -> dict:
    """Read access_control from policies.yaml with safe fallbacks."""
    try:
        return _load_policies().get("access_control", {})
    except Exception:
        return {}

def _monitoring_roles() -> set:
    return set(_get_access_control().get(
        "monitoring_roles",
        ["System Administrator", "Security Analyst", "Security Viewer"]
    ))

def _policy_admin_roles() -> set:
    return set(_get_access_control().get(
        "policy_admin_roles", ["Policy Administrator"]
    ))

def _device_admin_roles() -> set:
    return set(_get_access_control().get(
        "device_admin_roles", ["System Administrator"]
    ))

# REMARQUE : Ne pas mettre en cache MONITORING_ROLES au démarrage —
# le jeu doit être relu depuis policies.yaml à chaque requête
# pour que les changements UI prennent effet sans redémarrage.
MONITORING_ROLES = None   # sentinel — never used directly; use _monitoring_roles()


@app.route("/logging")
def logging_page():
    if not oidc.user_loggedin:
        return redirect(url_for("login"))
    if not token_is_valid(oidc, keycloak_openid):
        return render_template("error.html", message="Session expired."), 401
    roles = extract_user_role(oidc, keycloak_openid)
    if not any(r in _monitoring_roles() for r in roles):
        return render_template("error.html",
            message="Monitoring access requires Security Analyst, Viewer, or System Administrator."), 403
    return render_template("monitoring.html")


@app.route("/api/monitoring")
def api_monitoring():
    if not oidc.user_loggedin:
        return jsonify({"error": "Unauthorised"}), 401
    if not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Session expired"}), 401
    roles = extract_user_role(oidc, keycloak_openid)
    if not any(r in _monitoring_roles() for r in roles):
        return jsonify({"error": "Forbidden"}), 403

    # Synchronisation des échecs de TOUS les utilisateurs depuis Keycloak.
    # Garantit que le tableau de bord reflète l'état Keycloak actuel
    # pour tous les utilisateurs, pas seulement l'utilisateur connecté.
    # La déduplication par ensemble rend cela sûr à chaque sondage.
    _sync_all_users_failures()

    login_stats = get_all_login_stats()

    active_sessions = []
    try:
        from mysql_broker import get_active_sessions as _ms
        for tu, meta in _ms().items():
            exp = meta.get("expiry")
            active_sessions.append({
                "resource": "mysql", "temp_user": tu,
                "access_level": meta.get("access_level", "FULL_ACCESS"),
                "expires_at": exp.isoformat()+"Z" if hasattr(exp,"isoformat") else str(exp or ""),
            })
    except Exception as e:
        logger.warning(f"api_monitoring: mysql — {e}")

    try:
        from ssh_broker import get_active_sessions as _ss
        for tu, meta in _ss().items():
            exp = meta.get("expiry")
            active_sessions.append({
                "resource": "linux-server", "temp_user": tu,
                "access_level": meta.get("access_level", "FULL_ACCESS"),
                "expires_at": exp.isoformat()+"Z" if hasattr(exp,"isoformat") else str(exp or ""),
            })
    except Exception as e:
        logger.warning(f"api_monitoring: ssh — {e}")

    # ── Device agent status ───────────────────────────────────
    # Construction de la liste d'appareils depuis device_telemetry.json enrichie avec :
    #   - fraîcheur (agent en ligne / obsolète / hors ligne)
    #   - score calculé de l'appareil
    #   - correspondance utilisateur (quel utilisateur portail possède cet appareil,
    #     résolue en faisant correspondre last_ip avec les IPs de login_stats)
    import datetime as _dt

    device_list = []
    try:
        store   = _load_device_store()
        devices = store.get("devices", {})
        now_utc = _dt.datetime.now(_dt.timezone.utc)

        # Build ip->user_id map from login_stats events
        ip_to_user = {}
        for uid, stats in login_stats.items():
            for ev in (stats.get("events") or []):
                ip = ev.get("ip_address", "")
                if ip and ip not in ip_to_user:
                    ip_to_user[ip] = uid

        for did, info in devices.items():
            last_seen  = info.get("last_seen")
            last_ip    = info.get("last_ip", "")
            telemetry  = info.get("telemetry") or {}
            score      = _quick_device_score(telemetry) if telemetry else None

            # Classification de fraîcheur
            age_sec = None
            if last_seen:
                try:
                    seen    = _dt.datetime.fromisoformat(
                        last_seen.replace("Z", "+00:00")
                    )
                    age_sec = (now_utc - seen).total_seconds()
                except Exception:
                    pass

            if age_sec is None:
                agent_status = "never"
            elif age_sec <= 90:
                agent_status = "online"
            elif age_sec <= 300:
                agent_status = "stale"
            else:
                agent_status = "offline"

            # Infos OS depuis la télémétrie
            os_info   = telemetry.get("os", {})
            os_name   = os_info.get("system", "")
            os_build  = os_info.get("version", "")
            if os_name == "Windows":
                try:
                    build = int(os_build.split(".")[2])
                    os_name = "Windows 11" if build >= 22000 else "Windows 10"
                except Exception:
                    pass
            hostname  = info.get("hostname", "unknown")
            platform  = info.get("platform", "unknown")

            # Âge des signatures AV pour affichage
            av        = telemetry.get("antivirus", {})
            sig_age   = av.get("signature_age_days", -1)

            # Correspondance appareil → utilisateur portail via last_ip
            mapped_user = ip_to_user.get(last_ip)

            device_list.append({
                "device_id":    did,
                "hostname":     hostname,
                "platform":     platform,
                "os":           os_name or platform,
                "last_ip":      last_ip,
                "last_seen":    last_seen,
                "age_sec":      round(age_sec, 0) if age_sec is not None else None,
                "agent_status": agent_status,
                "device_score": score,
                "mapped_user":  mapped_user,
                "signals": {
                    "encryption": bool(telemetry.get("encryption", {}).get("enabled")),
                    "av_enabled": bool((telemetry.get("antivirus") or {}).get("av_enabled")),
                    "realtime":   bool((telemetry.get("antivirus") or {}).get("realtime_enabled")),
                    "sig_age":    sig_age,
                    "firewall":   bool((telemetry.get("firewall") or {}).get("enabled")),
                    "screen_lock":telemetry.get("screen_lock", {}).get("enabled"),
                    "domain":     bool((telemetry.get("domain") or {}).get("domain_joined")),
                    "ioc":        bool((telemetry.get("processes") or {}).get("hard_deny_triggered")),
                    "patch_days": (telemetry.get("patch") or {}).get("days_since_last_update", -1),
                },
            })

        device_list.sort(
            key=lambda d: d.get("last_seen") or "", reverse=True
        )

    except Exception as e:
        logger.warning(f"api_monitoring: device list — {e}")

    logger.info(
        f"api_monitoring: {len(login_stats)} users | "
        f"{len(active_sessions)} sessions | "
        f"{len(device_list)} devices"
    )

    # Comptage des événements IOC sur tous les appareils pour le badge
    store_for_ioc = _load_device_store()
    total_ioc_events = sum(
        len(info.get("ioc_events", []))
        for info in store_for_ioc.get("devices", {}).values()
    )

    return jsonify({
        "login_stats":      login_stats,
        "active":           active_sessions,
        "devices":          device_list,
        "ioc_event_count":  total_ioc_events,
    }), 200




def _resolve_device_id() -> str | None:
    """
    Return the device_id for the current request.

    Tries session first (set at login).  If the session has no device_id
    — because the agent sent its first heartbeat after the user logged in
    — fall back to a live IP lookup and heal the session so subsequent
    requests do not need the fallback.
    """
    device_id = session.get("device_id")
    if device_id:
        return device_id

    # Repli : résolution par l'IP courante du navigateur
    ip = request.headers.get(
        "X-Forwarded-For", request.remote_addr
    ).split(",")[0].strip()
    device_id = _find_device_id_for_ip(ip)

    if device_id:
        session["device_id"] = device_id   # heal the session
        logger.info(
            f"_resolve_device_id: healed session with "
            f"device_id={device_id} ip={ip}"
        )
    else:
        logger.info(
            f"_resolve_device_id: no device found for ip={ip}"
        )

    return device_id

def _find_device_id_for_ip(client_ip: str) -> str | None:
    """
    Resolve a device_id from the browser's client IP address.

    When the user opens the portal their browser and the ZT Agent are
    both running on the same machine, so both make requests from the
    same IP.  The heartbeat handler stores that IP as device["last_ip"].
    At login time we scan all registered devices for a last_ip match
    whose heartbeat is fresh enough (within 5 minutes).

    This is completely independent of usernames on either side — the
    Windows account name and the Keycloak username do not need to match.
    """
    if not client_ip:
        return None

    store   = _load_device_store()
    devices = store.get("devices", {})
    best_device_id = None
    best_age       = float("inf")

    for did, info in devices.items():
        stored_ip = info.get("last_ip", "")
        if not stored_ip or stored_ip != client_ip:
            continue

        last_seen = info.get("last_seen")
        if not last_seen:
            continue

        try:
            seen = datetime.datetime.fromisoformat(
                last_seen.replace("Z", "+00:00")
            )
            age = (
                datetime.datetime.now(datetime.timezone.utc) - seen
            ).total_seconds()

            if age <= 300 and age < best_age:   # 5-min window at login
                best_device_id = did
                best_age       = age
        except Exception:
            continue

    if best_device_id:
        logger.info(
            f"_find_device_id_for_ip: ip={client_ip} "
            f"-> {best_device_id} (age={best_age:.0f}s)"
        )
    else:
        logger.info(
            f"_find_device_id_for_ip: no fresh device found for ip={client_ip}"
        )

    return best_device_id



# ── Continuous session evaluation ────────────────────────────
# Compteurs de pulsations obsolètes par session.
# Révocation uniquement après STALE_REVOKE_THRESHOLD pulsations manquées consécutives.
# Les détections IOC contournent ce compteur et révoquent immédiatement.
_session_stale_counts: dict = {}

# Nombre de vérifications consécutives devant voir un agent obsolète
# avant de révoquer une session active. 4 manques ≈ 120s d'absence confirmée.
STALE_REVOKE_THRESHOLD = 4
# Called by the browser every 30s while a session is active.
# Re-evaluates trust for each active broker session.
# Revokes sessions where trust has dropped below threshold
# or a malicious process has been detected on the device.

@app.route("/api/session/check", methods=["POST"])
def api_session_check():
    """
    Re-evaluate trust for all active sessions belonging to the
    current user. Revokes sessions that no longer pass.

    Returns:
    {
      "sessions": [
        {
          "resource":  "mysql" | "linux-fs",
          "temp_user": str,
          "status":    "valid" | "revoked",
          "reason":    str | null,
          "trust_score": int | null
        }
      ]
    }
    """
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorised"}), 401

    auth_profile = session.get("oidc_auth_profile", {})
    user_id      = auth_profile.get("sub", "")
    user_agent   = request.headers.get("User-Agent", "")
    server_ip    = request.headers.get(
        "X-Forwarded-For", request.remote_addr
    ).split(",")[0].strip()

    # Use public IP if browser sent one
    data             = request.get_json(silent=True) or {}
    browser_public_ip = (data.get("public_ip") or "").strip()
    ip_address = (
        browser_public_ip
        if browser_public_ip and not _is_private_ip(browser_public_ip)
        else server_ip
    )

    results = []

    # Collect all active sessions across both brokers
    all_sessions = []
    try:
        from mysql_broker import get_active_sessions as _ms,                                   revoke_access as _mr
        for tu, meta in _ms().items():
            if meta.get("user_id") == user_id:
                all_sessions.append(("mysql", tu, meta, _mr))
    except Exception as e:
        logger.warning(f"session_check: mysql broker error — {e}")

    try:
        from ssh_broker import get_active_sessions as _ss,                                revoke_access as _sr
        for tu, meta in _ss().items():
            if meta.get("user_id") == user_id:
                all_sessions.append(("linux-server", tu, meta, _sr))
    except Exception as e:
        logger.warning(f"session_check: ssh broker error — {e}")

    if not all_sessions:
        return jsonify({"sessions": []}), 200

    # Re-evaluate trust once (shared across all sessions for this user)
    device_id  = _resolve_device_id()
    user_roles = all_sessions[0][2].get("user_roles", []) or                  extract_user_role(oidc, keycloak_openid) or []

    raw_token = oidc.get_access_token()
    token_iat = None
    if isinstance(raw_token, dict):
        token_iat = raw_token.get("iat")
    else:
        try:
            token_iat = keycloak_openid.introspect(raw_token).get("iat")
        except Exception:
            pass

    try:
        trust_result = call_trust_engine(
            user_id    = user_id,
            user_roles = user_roles,
            resource_id= all_sessions[0][0],   # primary resource
            ip_address = ip_address,
            user_agent = user_agent,
            token_iat  = token_iat,
            mfa_method = session.get("mfa_method"),
            device_id  = device_id,
            public_ip  = browser_public_ip or None,
        )
    except Exception as e:
        logger.error(f"session_check: Trust Engine error — {e}")
        return jsonify({"sessions": [{"resource": s[0], "temp_user": s[1],
                        "status": "valid", "reason": None,
                        "trust_score": None} for s in all_sessions]}), 200

    new_score   = trust_result.get("trust_score", 0)
    deny_reason = trust_result.get("deny_reason")
    breakdown   = trust_result.get("breakdown", {})

    logger.info(
        f"session_check: user={user_id[:8]}... re-eval score={new_score} "
        f"deny_reason={deny_reason!r} "
        f"active_sessions={[s[1] for s in all_sessions]}"
    )

    for resource_id, temp_user, meta, revoke_fn in all_sessions:
        # Load current minimum score for this resource/role
        try:
            pol       = _load_policies()
            res_cfg   = pol.get("resources", {}).get(resource_id, {})
            roles_cfg = res_cfg.get("roles", {})
            matched   = next((r for r in user_roles if r in roles_cfg), None)
            min_score = int(
                (roles_cfg.get(matched) or {}).get("min_trust_score_override")
                or res_cfg.get("min_trust_score", 70)
            )
        except Exception:
            min_score = 70

        # ── Classify the deny reason ──────────────────────────
        # Deux classes de refus :
        #
        #   CONFIRMÉ — processus IOC, blocage AbuseIPDB, score sous
        #   le seuil. Révocation immédiate — ce sont de vrais signaux.
        #
        #   INCERTAIN — pulsation agent obsolète. Peut être un vrai
        #   agent hors ligne, ou juste une pulsation retardée par
        #   des appels API lents (ipinfo, AbuseIPDB). Nécessite
        #   STALE_REVOKE_THRESHOLD lectures obsolètes consécutives
        #   avant révocation pour éviter les faux positifs.

        AGENT_STALE_PHRASES = (
            "heartbeat is stale",
            "no device agent detected",
            "no heartbeat received",
        )
        is_stale_deny = deny_reason and any(
            p in deny_reason.lower() for p in AGENT_STALE_PHRASES
        )

        revoke_reason  = None
        warning_reason = None   # shown to user without revoking

        if deny_reason and not is_stale_deny:
            # Confirmed hard deny — IOC, bot UA, AbuseIPDB block
            revoke_reason = deny_reason
            _session_stale_counts.pop(temp_user, None)

        elif is_stale_deny:
            # Incertain — incrémentation du compteur obsolète
            count = _session_stale_counts.get(temp_user, 0) + 1
            _session_stale_counts[temp_user] = count

            if count >= STALE_REVOKE_THRESHOLD:
                revoke_reason = (
                    f"Device agent has not sent a heartbeat for "
                    f"{count * 30}+ seconds. Session revoked — "
                    f"ensure the ZT Agent is running."
                )
                logger.warning(
                    f"session_check: agent stale for {count} consecutive "
                    f"polls ({count * 30}s) — revoking '{temp_user}'"
                )
            else:
                warning_reason = (
                    f"Device agent heartbeat delayed "
                    f"({count}/{STALE_REVOKE_THRESHOLD} missed checks). "
                    f"Session will be revoked if agent remains offline."
                )
                logger.info(
                    f"session_check: agent stale count {count}/"
                    f"{STALE_REVOKE_THRESHOLD} for '{temp_user}' — "
                    f"not revoking yet"
                )

        elif new_score < min_score:
            # Score dropped below resource threshold
            revoke_reason = (
                f"Trust score dropped to {new_score}/100 during your session "
                f"(minimum required: {min_score}/100). "
                f"Session revoked — re-authenticate to regain access."
            )
            _session_stale_counts.pop(temp_user, None)

        else:
            # Tout est bon — réinitialisation du compteur obsolète
            _session_stale_counts.pop(temp_user, None)

        if revoke_reason:
            logger.warning(
                f"session_check: REVOKING '{temp_user}' "
                f"resource={resource_id} score={new_score} "
                f"reason={revoke_reason[:80]}"
            )
            try:
                revoke_fn(temp_user)
            except Exception as e:
                logger.error(f"session_check: revoke failed — {e}")
            results.append({
                "resource":    resource_id,
                "temp_user":   temp_user,
                "status":      "revoked",
                "reason":      revoke_reason,
                "trust_score": new_score,
                "breakdown":   breakdown,
            })
        elif warning_reason:
            results.append({
                "resource":    resource_id,
                "temp_user":   temp_user,
                "status":      "warning",
                "reason":      warning_reason,
                "trust_score": new_score,
                "breakdown":   breakdown,
            })
        else:
            results.append({
                "resource":    resource_id,
                "temp_user":   temp_user,
                "status":      "valid",
                "reason":      None,
                "trust_score": new_score,
                "breakdown":   breakdown,
            })

    return jsonify({"sessions": results}), 200

@app.route("/api/session-history")
def api_session_history():
    """
    Return combined session history from MySQL and SSH brokers.
    Includes active and expired sessions, newest first.
    Enriches each entry with a resolved display username from login_stats.
    """
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorised"}), 401
    roles = extract_user_role(oidc, keycloak_openid)
    if not any(r in _monitoring_roles() for r in roles):
        return jsonify({"error": "Forbidden"}), 403

    history = []

    try:
        from mysql_broker import get_session_log as _msl
        history.extend(_msl())
    except Exception as e:
        logger.warning(f"api_session_history: mysql — {e}")

    try:
        from ssh_broker import get_session_log as _ssl
        history.extend(_ssl())
    except Exception as e:
        logger.warning(f"api_session_history: ssh — {e}")

    # Enrich with human-readable username from login_stats
    login_stats = get_all_login_stats()
    uid_to_email = {
        uid: (stats.get("email") or uid[:12] + "...")
        for uid, stats in login_stats.items()
    }

    for entry in history:
        uid = entry.get("user_id", "")
        entry["display_user"] = uid_to_email.get(uid, uid[:16] + "..." if uid else "--")

        # Mark active sessions without an end time
        if not entry.get("ended_at"):
            entry["ended_at"]     = None
            entry["ended_reason"] = "active"

    # Sort newest started first
    history.sort(key=lambda e: e.get("started_at") or "", reverse=True)

    return jsonify({"sessions": history[:300]}), 200


# ── Device Agent API ──────────────────────────────────────────
# These two endpoints support the ZT device agent test.
# Register: issues a device_id and shared HMAC secret.
# Heartbeat: validates the signature and stores telemetry.
# Received telemetry is stored in device_telemetry.json next
# to app.py and viewable at /api/device/latest.

import hashlib as _hashlib
import hmac    as _hmac

_DEVICE_TELEMETRY_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "device_telemetry.json"
)

def _load_device_store() -> dict:
    import json as _json
    if not os.path.exists(_DEVICE_TELEMETRY_FILE):
        return {"devices": {}}
    try:
        with open(_DEVICE_TELEMETRY_FILE, "r", encoding="utf-8") as f:
            return _json.load(f)
    except Exception:
        return {"devices": {}}

def _save_device_store(data: dict) -> None:
    import json as _json
    with open(_DEVICE_TELEMETRY_FILE, "w", encoding="utf-8") as f:
        _json.dump(data, f, indent=2, default=str)


@app.route("/api/device/register", methods=["POST"])
def device_register():
    """
    Register a new device agent.
    Body: { hostname, platform, fingerprint }
    Returns: { device_id, secret }
    No authentication required — the returned secret secures
    all subsequent heartbeats via HMAC-SHA256.
    """
    import secrets as _secrets, json as _json

    d = request.get_json(silent=True)
    if not d or not d.get("fingerprint"):
        return jsonify({"error": "fingerprint required"}), 400

    store = _load_device_store()

    # Return existing registration for same fingerprint
    for did, info in store["devices"].items():
        if info.get("fingerprint") == d["fingerprint"]:
            logger.info(f"device_register: re-registration {did} ({d.get('hostname','')})")
            return jsonify({"device_id": did, "secret": info["secret"]}), 200

    device_id = "dev_" + _secrets.token_hex(10)
    secret    = _secrets.token_hex(32)

    store["devices"][device_id] = {
        "device_id":   device_id,
        "hostname":    d.get("hostname", "unknown"),
        "platform":    d.get("platform", "unknown"),
        "fingerprint": d.get("fingerprint", ""),
        "secret":      secret,
        "registered":  datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "last_seen":   None,
        "telemetry":   None,
    }
    _save_device_store(store)
    logger.info(f"device_register: new device {device_id} ({d.get('hostname','')})")
    return jsonify({"device_id": device_id, "secret": secret}), 200


@app.route("/api/device/heartbeat", methods=["POST"])
def device_heartbeat():
    """
    Accept a signed telemetry heartbeat from the device agent.
    Headers: X-Device-ID, X-Device-Signature (HMAC-SHA256)
    Body:    raw JSON string (signed as-is)
    """
    import json as _json

    device_id = request.headers.get("X-Device-ID", "")
    signature = request.headers.get("X-Device-Signature", "")

    if not device_id or not signature:
        return jsonify({"error": "X-Device-ID and X-Device-Signature headers required"}), 400

    payload_str = request.get_data(as_text=True)
    store       = _load_device_store()
    device      = store["devices"].get(device_id)

    if not device:
        logger.warning(f"device_heartbeat: unknown device_id {device_id}")
        return jsonify({"error": "Device not registered"}), 404

    # Verify HMAC-SHA256 signature
    expected = _hmac.new(
        device["secret"].encode("utf-8"),
        payload_str.encode("utf-8"),
        _hashlib.sha256,
    ).hexdigest()

    if not _hmac.compare_digest(expected, signature):
        logger.warning(f"device_heartbeat: invalid signature from {device_id}")
        return jsonify({"error": "Invalid signature"}), 401

    # Parse and store telemetry
    try:
        payload   = _json.loads(payload_str)
        telemetry = payload.get("telemetry", {})
    except Exception:
        return jsonify({"error": "Invalid JSON body"}), 400

    now_ts = datetime.datetime.now(datetime.timezone.utc)
    device["last_seen"] = now_ts.isoformat()
    device["last_ip"]   = request.headers.get("X-Forwarded-For",
                              request.remote_addr).split(",")[0].strip()
    device["telemetry"] = telemetry

    # ── IOC event persistence ─────────────────────────────────
    # When the agent reports IOC processes, append a timestamped
    # event record to device["ioc_events"]. This survives the next
    # clean heartbeat so the monitoring dashboard retains history.
    procs_data   = telemetry.get("processes", {})
    ioc_detected = procs_data.get("ioc_detected") or []
    if isinstance(ioc_detected, str):
        ioc_detected = [ioc_detected]
    hard_deny    = procs_data.get("hard_deny_triggered", False)

    if ioc_detected or hard_deny:
        if "ioc_events" not in device:
            device["ioc_events"] = []
        # Avoid duplicate entries for the same IOC within a 60s window
        last_ioc_ts = None
        if device["ioc_events"]:
            try:
                last_ioc_ts = datetime.datetime.fromisoformat(
                    device["ioc_events"][-1]["timestamp"].replace("Z", "+00:00")
                )
            except Exception:
                pass
        age_since_last = (
            (now_ts - last_ioc_ts).total_seconds()
            if last_ioc_ts else 999
        )
        last_ioc_procs = (
            device["ioc_events"][-1].get("processes", [])
            if device["ioc_events"] else []
        )
        is_new = (age_since_last > 55) or (set(ioc_detected) != set(last_ioc_procs))
        if is_new:
            device["ioc_events"].append({
                "timestamp":  now_ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "hostname":   device.get("hostname", "unknown"),
                "platform":   device.get("platform", "unknown"),
                "processes":  ioc_detected,
                "hard_deny":  hard_deny,
            })
            logger.warning(
                f"device_heartbeat: IOC EVENT recorded for {device_id} "
                f"({device.get('hostname')}) — {ioc_detected}"
            )
        # Keep only last 100 IOC events per device
        device["ioc_events"] = device["ioc_events"][-100:]

    _save_device_store(store)

    # NOTE: we do NOT set session["device_id"] here.
    # The heartbeat comes from the agent (a Python process), not the browser.
    # Setting it here would write into the agent's ephemeral request session,
    # not the user's browser session.  Device resolution happens at /login
    # via IP matching in _find_device_id_for_ip().

    # Compute a quick device score preview
    score = _quick_device_score(telemetry)
    logger.info(
        f"device_heartbeat: accepted from {device_id} "
        f"({device['hostname']}) score={score}"
    )

    return jsonify({
        "status":           "accepted",
        "device_id":        device_id,
        "device_score":     score,
        "session_warnings": [],
    }), 200


@app.route("/api/ioc-events")
def api_ioc_events():
    """
    Return all IOC events recorded from device heartbeats,
    newest first. Used by the monitoring dashboard Security Events tab.
    """
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorised"}), 401
    roles = extract_user_role(oidc, keycloak_openid)
    if not any(r in _monitoring_roles() for r in roles):
        return jsonify({"error": "Forbidden"}), 403

    store   = _load_device_store()
    devices = store.get("devices", {})
    events  = []

    for device_id, info in devices.items():
        for ev in info.get("ioc_events", []):
            events.append({
                "device_id": device_id,
                "hostname":  ev.get("hostname", info.get("hostname", "unknown")),
                "platform":  ev.get("platform", info.get("platform", "unknown")),
                "timestamp": ev.get("timestamp", ""),
                "processes": ev.get("processes", []),
                "hard_deny": ev.get("hard_deny", True),
            })

    # Sort newest first
    events.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    return jsonify({"ioc_events": events[:200]}), 200


def _quick_device_score(t: dict) -> int:
    """Simple device score 0-100 mirroring agent preview logic."""
    score = 1.0
    enc   = t.get("encryption", {})
    av    = t.get("antivirus",  {})
    fw    = t.get("firewall",   {})
    patch = t.get("patch",      {})
    sl    = t.get("screen_lock",{})
    procs = t.get("processes",  {})

    if procs.get("hard_deny_triggered") or procs.get("ioc_detected"):
        return 0

    if not enc.get("enabled"):                   score -= 0.25
    if not av.get("av_present"):                 score -= 0.20
    elif not av.get("av_enabled"):               score -= 0.20
    elif not av.get("realtime_enabled"):         score -= 0.10
    else:
        sig_age = av.get("signature_age_days", 0) or 0
        if sig_age > 3:                          score -= 0.10

    if not fw.get("enabled"):                    score -= 0.15

    days = patch.get("days_since_last_update", 0) or 0
    if days > 60:                                score -= 0.25
    elif days > 30:                              score -= 0.15

    if not sl.get("enabled"):                    score -= 0.10
    elif (sl.get("timeout_seconds") or 0) > 600: score -= 0.05

    if t.get("domain", {}).get("domain_joined"): score = min(score + 0.05, 1.0)

    return round(max(0.0, min(1.0, score)) * 100)


@app.route("/api/device/latest")
def device_latest():
    """
    View the most recently received device telemetry.
    Accessible to System Administrator only.
    Used during testing to confirm the portal received the
    heartbeat correctly.
    """
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorized"}), 401
    roles = extract_user_role(oidc, keycloak_openid) or []
    if not any(r in _device_admin_roles() for r in roles):
        return jsonify({"error": "Forbidden"}), 403

    store = _load_device_store()
    # Return summary — most recently seen device first
    devices = store.get("devices", {})
    summary = []
    for did, info in devices.items():
        tel   = info.get("telemetry") or {}
        score = _quick_device_score(tel) if tel else None
        summary.append({
            "device_id":    did,
            "hostname":     info.get("hostname"),
            "platform":     info.get("platform"),
            "registered":   info.get("registered"),
            "last_seen":    info.get("last_seen"),
            "device_score": score,
            "telemetry":    tel,
        })
    summary.sort(key=lambda x: x.get("last_seen") or "", reverse=True)
    return jsonify({"devices": summary, "total": len(summary)}), 200



# ── Debug: device resolution diagnostics ──────────────────────
# Open while logged in as System Administrator:
# GET http://192.168.0.101:5000/api/debug-device
# Remove after confirming end-to-end works.

@app.route("/api/debug-device")
def debug_device():
    if not oidc.user_loggedin or not token_is_valid(oidc, keycloak_openid):
        return jsonify({"error": "Unauthorized"}), 401

    import json as _json

    browser_ip = request.headers.get(
        "X-Forwarded-For", request.remote_addr
    ).split(",")[0].strip()

    report = {}

    # 1. What IP does the portal see for this browser request?
    report["browser_ip"] = browser_ip

    # 2. What device_id is in the current session?
    report["session_device_id"] = session.get("device_id")

    # 3. Full contents of device_telemetry.json
    store   = _load_device_store()
    devices = store.get("devices", {})
    report["registered_devices"] = []

    for did, info in devices.items():
        report["registered_devices"].append({
            "device_id":  did,
            "hostname":   info.get("hostname"),
            "last_ip":    info.get("last_ip"),
            "last_seen":  info.get("last_seen"),
            "ip_matches_browser": info.get("last_ip") == browser_ip,
        })

    # 4. Run the lookup manually and show result
    report["lookup_result"] = _find_device_id_for_ip(browser_ip)

    # 5. Freshness check for each device
    report["freshness"] = []
    for did, info in devices.items():
        last_seen = info.get("last_seen")
        age_sec   = None
        fresh     = False
        if last_seen:
            try:
                seen    = datetime.datetime.fromisoformat(
                    last_seen.replace("Z", "+00:00")
                )
                age_sec = (
                    datetime.datetime.now(datetime.timezone.utc) - seen
                ).total_seconds()
                fresh   = age_sec <= 300
            except Exception:
                pass
        report["freshness"].append({
            "device_id": did,
            "last_seen": last_seen,
            "age_sec":   round(age_sec, 1) if age_sec is not None else None,
            "fresh_for_login": fresh,
        })

    # 6. Conclusion
    if not devices:
        report["conclusion"] = "No devices registered — run the test agent first."
    elif not report["lookup_result"]:
        ips_in_store = [i.get("last_ip") for i in devices.values()]
        report["conclusion"] = (
            f"IP mismatch or stale heartbeat. "
            f"Browser IP: {browser_ip}. "
            f"IPs stored in device_telemetry.json: {ips_in_store}. "
            f"If these differ, the agent and browser are on different network paths."
        )
    else:
        report["conclusion"] = (
            f"Lookup OK — device_id={report['lookup_result']}. "
            f"If session_device_id is None, you need to log out and log back in "
            f"AFTER the agent sends a heartbeat."
        )

    return jsonify(report), 200

# ── Entry point ───────────────────────────────────────────────

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
