# ─────────────────────────────────────────────────────────────
# ssh_broker.py
# Courtier de compte de service pour le serveur Linux (SSH).
#
# Lors d'un ACCORD :
#   1. Crée un utilisateur Linux temporaire avec un mot de passe aléatoire
#   2. Ajoute une règle UFW pour l'IP client (ignoré
#      si le client est le serveur portail — règle permanente déjà en place)
#   3. Remet les règles de refus en bas
#   4. Planifie la révocation automatique après la durée de session
#
# Lors d'une RÉVOCATION :
#   1. Ferme toutes les sessions actives de l'utilisateur temporaire
#   2. Supprime l'utilisateur Linux temporaire et son répertoire
#   3. Supprime la règle UFW par tag de commentaire
#      (ignoré si le client était le serveur portail)
#   4. Remet les règles de refus en bas
#
# Règles UFW permanentes (définies manuellement une fois sur Kali) :
#   sudo ufw allow from <portal_ip> to any port 22 comment "ZT Portail courtier permanent"
#   sudo ufw deny 22
# ─────────────────────────────────────────────────────────────

import logging
import secrets
import string
import threading
from datetime import datetime, timedelta

import paramiko

logger = logging.getLogger(__name__)

# ── Configuration ────────────────────────────────────────────
SSH_HOST           = "192.168.0.102"           # Linux file server
SSH_PORT           = 22
SSH_ADMIN_USER     = "zt_admin"
SSH_ADMIN_PASSWORD = "your-zt-admin-password"  # ← zt_admin password
SSH_SESSIONS_DIR   = "/home/zt_sessions"
# IP portail auto-détectée lors du premier usage
def _get_portal_ip() -> str:
    import socket as _socket
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
        s.connect((SSH_HOST, 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

PORTAL_SERVER_IP: str = ""   # resolved lazily on first use

# Suivi des sessions actives
# { nom_temp: { "expiry": datetime, "client_ip": str } }
_active_sessions: dict = {}
_lock = threading.Lock()

_session_log: list = []
SESSION_LOG_MAX = 500

def _append_session_log(entry: dict) -> None:
    global _session_log
    with _lock:
        _session_log.append(entry)
        if len(_session_log) > SESSION_LOG_MAX:
            _session_log = _session_log[-SESSION_LOG_MAX:]


# ── Helpers ───────────────────────────────────────────────────

def _generate_password(length: int = 20) -> str:
    """Generate a cryptographically secure random password."""
    alphabet = string.ascii_letters + string.digits + "!@#"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _safe_username(user_id: str) -> str:
    """
    Derive a safe Linux username from the Keycloak sub UUID.
    Linux usernames max 32 chars, alphanumeric and underscores only.
    Result: zts_ + first 16 chars of UUID with hyphens removed.
    """
    cleaned = user_id.replace("-", "")[:16]
    return f"zts_{cleaned}"


def _get_ssh_client() -> paramiko.SSHClient:
    """Open an SSH connection to the file server using the service account."""
    import socket as _socket

    # Vérification préalable : test de connectivité TCP (échec rapide et clair)
    try:
        sock = _socket.create_connection((SSH_HOST, SSH_PORT), timeout=5)
        sock.close()
    except _socket.timeout:
        raise RuntimeError(
            f"ssh_broker: TCP connection to {SSH_HOST}:{SSH_PORT} timed out. "
            f"Check: (1) file server is running, (2) UFW allows portal IP on port 22, "
            f"(3) SSH service is active — 'sudo systemctl status ssh' on the server."
        )
    except ConnectionRefusedError:
        raise RuntimeError(
            f"ssh_broker: Connection refused to {SSH_HOST}:{SSH_PORT}. "
            f"SSH service is not running — 'sudo systemctl start ssh' on the server."
        )
    except OSError as e:
        raise RuntimeError(
            f"ssh_broker: Cannot reach {SSH_HOST}:{SSH_PORT} — {e}. "
            f"Check network connectivity between portal and file server."
        )

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname = SSH_HOST,
            port     = SSH_PORT,
            username = SSH_ADMIN_USER,
            password = SSH_ADMIN_PASSWORD,
            timeout  = 15,
            allow_agent      = False,
            look_for_keys    = False,
            auth_timeout     = 10,
        )
    except paramiko.AuthenticationException:
        raise RuntimeError(
            f"ssh_broker: Authentication failed for {SSH_ADMIN_USER}@{SSH_HOST}. "
            f"Check SSH_ADMIN_PASSWORD in ssh_broker.py matches the account password."
        )
    except paramiko.SSHException as e:
        raise RuntimeError(
            f"ssh_broker: SSH negotiation failed with {SSH_HOST} — {e}. "
            f"Check PasswordAuthentication=yes in /etc/ssh/sshd_config on the server."
        )
    return client


def _run(client: paramiko.SSHClient, command: str) -> tuple:
    """
    Execute a command over SSH.
    Returns (stdout, stderr, exit_code).
    """
    stdin, stdout, stderr = client.exec_command(command)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    if err:
        logger.debug(f"ssh_broker cmd stderr: {err}")
    return out, err, exit_code


def _sink_deny_rules(client: paramiko.SSHClient) -> None:
    """
    Delete and re-add the deny rules for port 22 so they always
    sit at the bottom of the UFW table, below all allow rules.
    Run twice to catch both IPv4 and IPv6 deny entries.
    """
    _run(client, "sudo ufw delete deny 22 2>/dev/null || true")
    _run(client, "sudo ufw delete deny 22 2>/dev/null || true")
    _run(client, "sudo ufw deny 22")
    logger.debug("ssh_broker: deny rules re-sunk to bottom of UFW table")


# ── Core functions ────────────────────────────────────────────

def provision_access(
    user_id:          str,
    access_level:     str,
    duration_minutes: int = 60,
    client_ip:        str = "",
    device_id:        str = "",
    user_roles:       list = None,
    resource_id:      str = "linux-server",
) -> dict:
    """
    Create a temporary Linux user and open a per-session firewall
    rule allowing only the requesting IP to SSH on port 22.

    If the client IP is the portal server IP, the per-session UFW
    rule is skipped — the permanent rule already covers it.

    Args:
        user_id:          Keycloak sub UUID
        access_level:     'FULL_ACCESS' or 'READ_ONLY'
        duration_minutes: Session duration in minutes
        client_ip:        IP of the user's machine from portal request

    Returns:
        dict with host, port, protocol, username, password,
        access_level, expires_at, duration_minutes, connect_command

    Raises:
        RuntimeError if the SSH operation fails
    """
    if not client_ip:
        raise RuntimeError(
            "Client IP is required to provision SSH access. "
            "Cannot manage firewall rules without a source IP."
        )

    temp_user = _safe_username(user_id)
    temp_pass = _generate_password()
    expiry    = datetime.utcnow() + timedelta(minutes=duration_minutes)

    try:
        client = _get_ssh_client()

        # ── 1. Nettoyage de toute session résiduelle pour cet utilisateur ──
        # Forcer la fermeture de tous les processus — userdel échoue si l'utilisateur
        # a encore des processus actifs (ex. : session SSH précédente
        # qui ne s'est pas révoquée proprement).
        _run(client, f"sudo pkill -9 -u {temp_user} 2>/dev/null || true")
        # Pause brève pour laisser le noyau récupérer les processus tués
        _run(client, "sleep 1")
        # Suppression de l'utilisateur et de son répertoire
        _run(client, f"sudo userdel -rf {temp_user} 2>/dev/null || true")
        # Suppression explicite du répertoire si userdel l'a laissé
        _run(
            client,
            f"sudo rm -rf {SSH_SESSIONS_DIR}/{temp_user} 2>/dev/null || true"
        )
        # Nettoyage de tout bloc Match sshd résiduel d'une session précédente
        _run(
            client,
            f"sudo rm -f /etc/ssh/sshd_config.d/zt-ro-{temp_user}.conf "
            f"/usr/local/bin/zt-ro-shell-{temp_user}.sh 2>/dev/null || true"
        )

        # ── 2. Création de l'utilisateur temporaire ──────────────────
        out, err, code = _run(
            client,
            f"sudo useradd -m -d {SSH_SESSIONS_DIR}/{temp_user} "
            f"-s /bin/bash {temp_user}"
        )
        if code != 0:
            # Dernier recours : si l'utilisateur existe encore, réinitialiser son mot de passe
            # et réutiliser le compte plutôt que d'échouer l'accord
            check_out, _, check_code = _run(
                client, f"id {temp_user} 2>/dev/null"
            )
            if check_code == 0:
                logger.warning(
                    f"ssh_broker: could not delete '{temp_user}' — "
                    f"resetting password and reusing existing account"
                )
            else:
                raise RuntimeError(f"useradd failed: {err}")

        # ── 3. Définition du mot de passe ────────────────────────────
        out, err, code = _run(
            client,
            f"echo '{temp_user}:{temp_pass}' | sudo chpasswd"
        )
        if code != 0:
            raise RuntimeError(f"chpasswd failed: {err}")

        # ── 4. Apply access level ─────────────────────────────
        # FULL_ACCESS : shell bash standard — l'utilisateur peut naviguer
        #              sur tout le système de fichiers selon les permissions Linux
        #              normales d'un compte sans privilèges.
        #
        # READ_ONLY :  Appliqué via sshd_config Match + ForceCommand.
        # READ_ONLY : appliqué via sshd Match + ForceCommand.
        #             Lance un shell restreint dans le répertoire de travail.
        #                - /var/log et répertoire home exposés en lecture seule
        #                - Aucun accès en écriture nulle part
        #                - Aucun chemin d'échappement via .bashrc/.profile
        #                  (répertoire home appartenant à root, pas à l'utilisateur)
        #
        # Implémentation : écriture d'un bloc Match par utilisateur dans
        # /etc/ssh/sshd_config.d/ and reload sshd.  This is the
        # production-grade approach — ForceCommand cannot be
        # ne peut pas être contourné par l'utilisateur contrairement à rbash.

        if access_level == "FULL_ACCESS":
            _run(client, f"sudo usermod -s /bin/bash {temp_user}")
            # Ensure any stale read-only config is removed
            _run(
                client,
                f"sudo rm -f /etc/ssh/sshd_config.d/zt-ro-{temp_user}.conf"
                f" 2>/dev/null || true"
            )
            logger.info(f"ssh_broker: FULL_ACCESS — full bash shell for '{temp_user}'")
        else:
            # ── READ_ONLY enforcement ─────────────────────────
            # Étape 1 : l'utilisateur conserve bash comme shell de connexion
            #         (nécessaire pour que ForceCommand fonctionne correctement)
            _run(client, f"sudo usermod -s /bin/bash {temp_user}")

            # Étape 2 : répertoire home appartenant à root pour que .bashrc/.profile
            #         cannot be modified and used to escape restrictions
            _run(
                client,
                f"sudo chown root:root {SSH_SESSIONS_DIR}/{temp_user} "
                f"&& sudo chmod 755 {SSH_SESSIONS_DIR}/{temp_user}"
            )

            # Étape 3 : création d'un répertoire de travail que l'utilisateur peut
            #         actually write to (for sftp downloads etc.)
            _run(
                client,
                f"sudo mkdir -p {SSH_SESSIONS_DIR}/{temp_user}/workspace "
                f"&& sudo chown {temp_user}:{temp_user} "
                f"{SSH_SESSIONS_DIR}/{temp_user}/workspace "
                f"&& sudo chmod 700 {SSH_SESSIONS_DIR}/{temp_user}/workspace"
            )

            # Étape 4 : écriture d'un bloc Match sshd par utilisateur avec
            #         ForceCommand to launch a restricted shell wrapper.
            #         ForceCommand overrides whatever command the client
            #         sends — it cannot be bypassed from the client side.
            ro_script = f"/usr/local/bin/zt-ro-shell-{temp_user}.sh"
            sshd_conf = f"/etc/ssh/sshd_config.d/zt-ro-{temp_user}.conf"

            # Le wrapper shell restreint :
            #   - Change vers le répertoire de travail de l'utilisateur
            #   - Supprime les variables d'environnement dangereuses
            #   - Lance bash avec un PATH restreint (répertoires en lecture seule)
            #   - HISTFILE=/dev/null empêche la persistance de l'historique
            shell_script = (
                "#!/bin/bash\n"
                "# ZT READ_ONLY shell wrapper — auto-generated, do not edit\n"
                f"cd {SSH_SESSIONS_DIR}/{temp_user}/workspace\n"
                "export PATH=/usr/bin:/bin\n"
                "export HISTFILE=/dev/null\n"
                "export HOME=" + f"{SSH_SESSIONS_DIR}/{temp_user}" + "\n"
                "# Present a clear message about restrictions\n"
                'echo "ZT READ-ONLY session. Working directory: $(pwd)"\n'
                'echo "Allowed: ls, cat, grep, head, tail, find, wc, sort, less, more"\n'
                'echo "Restricted: cd (outside workspace), write operations, sudo"\n'
                'echo ""\n'
                "exec bash --restricted --norc --noprofile"
            )

            # Écriture du wrapper shell
            _run(
                client,
                f"echo -e '{shell_script}' | sudo tee {ro_script} > /dev/null"
                f" && sudo chmod 755 {ro_script}"
            )

            # Écriture du bloc Match sshd avec ForceCommand
            sshd_block = (
                f"# ZT READ_ONLY session config for {temp_user}\n"
                f"Match User {temp_user}\n"
                f"    ForceCommand {ro_script}\n"
                f"    AllowTcpForwarding no\n"
                f"    X11Forwarding no\n"
                f"    PermitTTY yes\n"
            )
            _run(
                client,
                f"echo -e '{sshd_block}' | sudo tee {sshd_conf} > /dev/null"
            )

            # Rechargement sshd pour activer le bloc Match
            _, _, reload_rc = _run(
                client,
                "sudo sshd -t 2>/dev/null && sudo systemctl reload ssh "
                "2>/dev/null || sudo systemctl reload sshd 2>/dev/null || true"
            )
            logger.info(
                f"ssh_broker: READ_ONLY — ForceCommand restricted shell "
                f"configured for '{temp_user}' via {sshd_conf}"
            )

                # ── 5. Règle UFW par session ─────────────────────────────────
        global PORTAL_SERVER_IP
        if not PORTAL_SERVER_IP:
            PORTAL_SERVER_IP = _get_portal_ip()
            logger.info(f"ssh_broker: portal IP resolved as {PORTAL_SERVER_IP}")
        if client_ip == PORTAL_SERVER_IP:
            # Portal server already has a permanent UFW rule.
            # Adding a duplicate would be redundant — skip it.
            logger.info(
                f"ssh_broker: client_ip={client_ip} matches portal server "
                f"— skipping per-session UFW rule (permanent rule covers it)"
            )
        else:
            ufw_comment = f"ZT-session-{temp_user}"
            out, err, code = _run(
                client,
                f"sudo ufw allow from {client_ip} to any port 22 "
                f"comment '{ufw_comment}'"
            )
            logger.info(
                f"ssh_broker: UFW allow result — "
                f"code={code} out='{out}' err='{err}'"
            )
            if code != 0:
                logger.warning(
                    f"ssh_broker: UFW rule failed for {client_ip}: {err}"
                )
            else:
                logger.info(
                    f"ssh_broker: UFW rule added — "
                    f"allow {client_ip} → port 22 [{ufw_comment}]"
                )

        # ── 6. Re-sink deny rules to bottom ───────────────────
        _sink_deny_rules(client)

        client.close()

        logger.info(
            f"ssh_broker: provisioned '{temp_user}' "
            f"client_ip={client_ip} level='{access_level}' "
            f"expires={expiry.isoformat()}"
        )

        # Suivi de session — inclut le contexte utilisateur pour la réévaluation
        now_iso = datetime.utcnow().isoformat() + "Z"
        with _lock:
            _active_sessions[temp_user] = {
                "expiry":       expiry,
                "client_ip":    client_ip,
                "device_id":    device_id,
                "user_id":      user_id,
                "user_roles":   user_roles or [],
                "resource_id":  resource_id,
                "access_level": access_level,
                "started_at":   now_iso,
            }

        _append_session_log({
            "resource":     resource_id or "linux-server",
            "protocol":     "SSH",
            "temp_user":    temp_user,
            "user_id":      user_id,
            "user_roles":   user_roles or [],
            "access_level": access_level,
            "client_ip":    client_ip,
            "started_at":   now_iso,
            "ended_at":     None,
            "ended_reason": None,
        })

        # Planification de la révocation automatique
        _schedule_revocation(temp_user, duration_minutes * 60)

        return {
            "host":             SSH_HOST,
            "port":             SSH_PORT,
            "protocol":         "SSH",
            "username":         temp_user,
            "password":         temp_pass,
            "access_level":     access_level,
            "expires_at":       expiry.isoformat() + "Z",
            "duration_minutes": duration_minutes,
            "connect_command":  f"ssh {temp_user}@{SSH_HOST}",
        }

    except RuntimeError:
        raise
    except Exception as e:
        logger.error(f"ssh_broker: provision_access failed — {e}")
        raise RuntimeError(f"Could not provision SSH access: {e}")


def revoke_access(temp_user: str) -> bool:
    """
    Kill active sessions, delete the temporary Linux user,
    remove the per-session UFW rule (if applicable),
    and re-sink deny rules to the bottom.
    Returns True on success, False on failure.
    """
    try:
        # Récupération des données de session avant suppression du suivi
        with _lock:
            session_data = _active_sessions.get(temp_user, {})
            client_ip    = session_data.get("client_ip", "")

        client = _get_ssh_client()

        # ── 1. Suppression du bloc Match sshd par utilisateur (READ_ONLY) ─
        sshd_conf = f"/etc/ssh/sshd_config.d/zt-ro-{temp_user}.conf"
        ro_script = f"/usr/local/bin/zt-ro-shell-{temp_user}.sh"
        _run(client, f"sudo rm -f {sshd_conf} {ro_script} 2>/dev/null || true")
        # Rechargement sshd pour désactiver le bloc Match
        _run(
            client,
            "sudo sshd -t 2>/dev/null && sudo systemctl reload ssh "
            "2>/dev/null || sudo systemctl reload sshd 2>/dev/null || true"
        )

        # ── 2. Fermeture forcée de toutes les sessions SSH ───────────
        # Use SIGKILL (-9) for instant termination — no grace period.
        # This is intentional: mid-session revocation must be immediate.
        # 1a. Kill all processes owned by temp_user
        _run(client, f"sudo pkill -9 -u {temp_user} 2>/dev/null || true")
        # 1b. Find and close any pts (pseudo-terminal) sessions for this user
        out, _, _ = _run(client, f"sudo who | grep {temp_user} | awk '{{print $2}}'")
        for pts in out.splitlines():
            pts = pts.strip()
            if pts.startswith("pts"):
                _run(client, f"sudo pkill -9 -t {pts} 2>/dev/null || true")
                logger.info(f"ssh_broker: force-killed pts session {pts} for '{temp_user}'")
        logger.info(f"ssh_broker: SIGKILL sent — all sessions for '{temp_user}' terminated")

        # ── 2. Delete the user and home directory ─────────────
        _run(client, f"sudo userdel -r {temp_user} 2>/dev/null || true")
        logger.info(f"ssh_broker: deleted user '{temp_user}'")

        # ── 3. Remove per-session UFW rule ────────────────────
        global PORTAL_SERVER_IP
        if not PORTAL_SERVER_IP:
            PORTAL_SERVER_IP = _get_portal_ip()
        if client_ip and client_ip != PORTAL_SERVER_IP:
            # Supprime uniquement les règles pour les IP non-portail.
            # La règle permanente du serveur portail ne doit jamais être modifiée.
            ufw_comment = f"ZT-session-{temp_user}"

            out, _, _ = _run(
                client,
                f"sudo ufw status numbered | grep '{ufw_comment}' | "
                f"awk -F'[][]' '{{print $2}}'"
            )

            rule_numbers = [
                r.strip() for r in out.splitlines()
                if r.strip().isdigit()
            ]

            if rule_numbers:
                for num in sorted(rule_numbers, reverse=True):
                    _run(client, f"echo 'y' | sudo ufw delete {num}")
                    logger.info(
                        f"ssh_broker: removed UFW rule #{num} "
                        f"for {client_ip} [{ufw_comment}]"
                    )
            else:
                logger.warning(
                    f"ssh_broker: no UFW rule found for "
                    f"comment '{ufw_comment}' — may already be removed"
                )

        elif client_ip == PORTAL_SERVER_IP:
            logger.info(
                f"ssh_broker: client_ip is portal server — "
                f"permanent UFW rule preserved, no per-session rule to remove"
            )

        # ── 4. Re-sink deny rules to bottom ───────────────────
        _sink_deny_rules(client)

        client.close()

        with _lock:
            _active_sessions.pop(temp_user, None)

        ended_iso = datetime.utcnow().isoformat() + "Z"
        with _lock:
            for entry in reversed(_session_log):
                if entry.get("temp_user") == temp_user and entry.get("ended_at") is None:
                    entry["ended_at"]     = ended_iso
                    entry["ended_reason"] = "revoked"
                    break

        logger.info(
            f"ssh_broker: fully revoked '{temp_user}' "
            f"client_ip={client_ip}"
        )
        return True

    except Exception as e:
        logger.error(f"ssh_broker: revoke_access failed — {e}")
        return False


def get_session_log() -> list:
    """Return the SSH session history log (most recent first)."""
    with _lock:
        return list(reversed(_session_log))


def get_active_sessions() -> dict:
    """Return all currently active temporary SSH sessions."""
    with _lock:
        return dict(_active_sessions)


# ── Internal ──────────────────────────────────────────────────

def _schedule_revocation(temp_user: str, delay_seconds: int) -> None:
    """Schedule automatic revocation after session duration."""
    def _revoke():
        logger.info(f"ssh_broker: timer fired — revoking '{temp_user}'")
        revoke_access(temp_user)

    timer        = threading.Timer(delay_seconds, _revoke)
    timer.daemon = True
    timer.start()
    logger.info(
        f"ssh_broker: auto-revocation scheduled for '{temp_user}' "
        f"in {delay_seconds}s ({delay_seconds // 60} min)"
    )
