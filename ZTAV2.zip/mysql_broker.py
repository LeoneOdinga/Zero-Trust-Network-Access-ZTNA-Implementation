# ─────────────────────────────────────────────────────────────
# mysql_broker.py
# Courtier de compte de service pour la base de données MySQL.
#
# Lors d'un ACCORD :
#   1. Crée un utilisateur MySQL temporaire avec un mot de passe aléatoire
#   2. Ajoute une règle UFW par session autorisant UNIQUEMENT l'IP
#      demandeuse sur le port 3306 (ignoré si client = serveur portail —
#      règle permanente déjà en place)
#   3. Remet les règles de refus au bas de la liste UFW
#   4. Planifie la révocation automatique après la durée de session
#
# Lors d'une RÉVOCATION :
#   1. Ferme les connexions MySQL actives de l'utilisateur temporaire
#   2. Supprime l'utilisateur MySQL temporaire
#   3. Supprime la règle UFW par tag de commentaire
#      (ignoré si le client était le serveur portail)
#   4. Remet les règles de refus au bas de la liste UFW
#
# Règles UFW permanentes (définies manuellement une fois sur Kali) :
#   sudo ufw allow from <portal_ip> to any port 3306 comment "ZT Portail MySQL courtier permanent"
#   sudo ufw deny 3306
#
# Mettre à jour toutes les valeurs de configuration avant utilisation.
# ─────────────────────────────────────────────────────────────

import logging
import secrets
import string
import threading
from datetime import datetime, timedelta

import mysql.connector
import paramiko

logger = logging.getLogger(__name__)

# ── Configuration du compte de service MySQL ─────────────────
MYSQL_HOST     = "192.168.0.102"            # ← Kali machine IP
MYSQL_PORT     = 3306
MYSQL_USER     = "zt_service"
MYSQL_PASSWORD = "StrongServicePass123!"
MYSQL_DATABASE = "ztportal"

MYSQL_CONFIG = {
    "host":     MYSQL_HOST,
    "port":     MYSQL_PORT,
    "user":     MYSQL_USER,
    "password": MYSQL_PASSWORD,
    "database": MYSQL_DATABASE,
}

# ── Configuration du compte SSH (gestion UFW) ────────────────
SSH_HOST           = MYSQL_HOST            # same machine as MySQL
SSH_PORT           = 22
SSH_ADMIN_USER     = "zt_admin"
SSH_ADMIN_PASSWORD = "your-zt-admin-password"  # ← zt_admin password

# ── Portal server IP ──────────────────────────────────────────
# Auto-détectée à l'import depuis l'interface sortante.
# C'est l'IP que le serveur MySQL voit lors de la connexion du courtier.
# Aucun codage en dur — fonctionne automatiquement après un changement d'IP.

def _get_portal_ip() -> str:
    """
    Detect the portal server's own IP by opening a UDP socket
    toward the MySQL host.  The OS picks the right interface
    without sending any actual traffic.
    """
    import socket as _socket
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
        s.connect((MYSQL_HOST, 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

PORTAL_SERVER_IP: str = ""   # resolved lazily on first use

# Suivi des sessions actives
# { nom_temp: { "expiry": datetime, "client_ip": str } }
_active_sessions: dict = {}
_lock = threading.Lock()

# Historique des sessions — enregistré lors de la création ou révocation.
# Conservé en mémoire (500 dernières entrées).
# Format : { resource, temp_user, user_id, access_level, client_ip,
#             started_at, ended_at, ended_reason }
_session_log: list = []
SESSION_LOG_MAX = 500


def _append_session_log(entry: dict) -> None:
    """Append a session event to the in-memory log (thread-safe)."""
    global _session_log
    with _lock:
        _session_log.append(entry)
        if len(_session_log) > SESSION_LOG_MAX:
            _session_log = _session_log[-SESSION_LOG_MAX:]


# ── MySQL helpers ─────────────────────────────────────────────

def _generate_password(length: int = 20) -> str:
    """Generate a cryptographically secure random password."""
    alphabet = string.ascii_letters + string.digits + "!@#$"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _get_mysql_connection():
    """Open a MySQL connection using the service account."""
    return mysql.connector.connect(**MYSQL_CONFIG)


def _safe_username(user_id: str) -> str:
    """
    Derive a safe MySQL username from the Keycloak sub UUID.
    MySQL usernames max 32 chars, no hyphens.
    Result: zt_ + first 20 chars of UUID with hyphens removed.
    """
    cleaned = user_id.replace("-", "")[:20]
    return f"zt_{cleaned}"


# ── SSH helpers (for UFW management) ─────────────────────────

def _get_ssh_client() -> paramiko.SSHClient:
    """Open an SSH connection to Kali using the service account."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname = SSH_HOST,
        port     = SSH_PORT,
        username = SSH_ADMIN_USER,
        password = SSH_ADMIN_PASSWORD,
        timeout  = 10,
    )
    return client


def _run(client: paramiko.SSHClient, command: str) -> tuple:
    """
    Execute a command over SSH.
    Returns (stdout, stderr, exit_code).
    """
    stdin, stdout, stderr = client.exec_command(command)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    if err:
        logger.debug(f"mysql_broker cmd stderr: {err}")
    return out, err, exit_code


def _ensure_portal_rule(client: paramiko.SSHClient) -> None:
    """
    Ensure a permanent UFW rule allows the portal server to reach
    MySQL on port 3306.  Called automatically on every provision —
    safe to call multiple times (UFW skips duplicates silently).
    Also ensures the default deny rule for port 3306 exists.
    No manual UFW setup required on the MySQL server.
    """
    global PORTAL_SERVER_IP
    if not PORTAL_SERVER_IP:
        PORTAL_SERVER_IP = _get_portal_ip()

    permanent_comment = "ZT-Portal-MySQL-permanent"

    # Vérification si la règle permanente existe déjà
    out, _, _ = _run(
        client,
        f"sudo ufw status | grep '{permanent_comment}'"
    )
    if permanent_comment in out:
        logger.debug(
            f"mysql_broker: permanent portal rule already exists — skipping"
        )
    else:
        _, err, code = _run(
            client,
            f"sudo ufw allow from {PORTAL_SERVER_IP} to any port 3306 "
            f"comment '{permanent_comment}'"
        )
        if code == 0:
            logger.info(
                f"mysql_broker: permanent portal rule added — "
                f"allow {PORTAL_SERVER_IP} -> port 3306"
            )
        else:
            logger.warning(
                f"mysql_broker: could not add permanent portal rule: {err}"
            )

    # Garantit l'existence de la règle de refus par défaut (sera resynchronisée)
    out2, _, _ = _run(
        client,
        "sudo ufw status | grep 'DENY' | grep '3306'"
    )
    if not out2:
        _run(client, "sudo ufw deny 3306")
        logger.info("mysql_broker: default deny rule for port 3306 added")


def _sink_deny_rules(client: paramiko.SSHClient) -> None:
    """
    Delete and re-add the deny rules for port 3306 so they always
    sit at the bottom of the UFW table, below all allow rules.
    Run twice to catch both IPv4 and IPv6 deny entries.
    """
    _run(client, "sudo ufw delete deny 3306 2>/dev/null || true")
    _run(client, "sudo ufw delete deny 3306 2>/dev/null || true")
    _run(client, "sudo ufw deny 3306")
    logger.debug("mysql_broker: deny rules re-sunk to bottom of UFW table")


# ── Core functions ────────────────────────────────────────────

def provision_access(
    user_id:          str,
    access_level:     str,
    duration_minutes: int = 30,
    client_ip:        str = "",
    device_id:        str = "",
    user_roles:       list = None,
    resource_id:      str = "mysql",
) -> dict:
    """
    Create a temporary MySQL user and open a per-session UFW rule
    allowing only the requesting IP to connect on port 3306.

    If the client IP is the portal server IP, the per-session UFW
    rule is skipped — the permanent rule already covers it.

    Args:
        user_id:          Keycloak sub UUID
        access_level:     'FULL_ACCESS' or 'READ_ONLY'
        duration_minutes: Session duration in minutes
        client_ip:        IP of the user's machine from portal request

    Returns:
        dict with host, port, database, username, password,
        expires_at, duration_minutes

    Raises:
        RuntimeError if MySQL or SSH operation fails
    """
    if not client_ip:
        raise RuntimeError(
            "Client IP is required to provision MySQL access. "
            "Cannot manage firewall rules without a source IP."
        )

    temp_user = _safe_username(user_id)
    temp_pass = _generate_password()
    expiry    = datetime.utcnow() + timedelta(minutes=duration_minutes)

    # ── Step 1: MySQL user creation ───────────────────────────
    try:
        conn   = _get_mysql_connection()
        cursor = conn.cursor()

        # Suppression si déjà existant — gère les nouvelles demandes
        cursor.execute(f"DROP USER IF EXISTS '{temp_user}'@'%';")

        # Création de l'utilisateur temporaire
        cursor.execute(
            f"CREATE USER '{temp_user}'@'%' IDENTIFIED BY '{temp_pass}';"
        )

        # Attribution selon le niveau d'accès
        if access_level == "FULL_ACCESS":
            cursor.execute(
                f"GRANT SELECT, INSERT, UPDATE, DELETE "
                f"ON {MYSQL_DATABASE}.* TO '{temp_user}'@'%';"
            )
            logger.info(f"mysql_broker: FULL_ACCESS granted to '{temp_user}'")
        else:
            cursor.execute(
                f"GRANT SELECT ON {MYSQL_DATABASE}.* TO '{temp_user}'@'%';"
            )
            logger.info(f"mysql_broker: READ_ONLY granted to '{temp_user}'")

        conn.commit()
        cursor.close()
        conn.close()

    except Exception as e:
        logger.error(f"mysql_broker: MySQL user creation failed — {e}")
        raise RuntimeError(f"Could not create MySQL user: {e}")

    # ── Step 2: UFW management ───────────────────────────────
    try:
        global PORTAL_SERVER_IP
        if not PORTAL_SERVER_IP:
            PORTAL_SERVER_IP = _get_portal_ip()
            logger.info(f"mysql_broker: portal IP resolved as {PORTAL_SERVER_IP}")

        ssh = _get_ssh_client()

        # Always ensure the portal's own permanent rule exists first.
        # Idempotent — UFW ignore silencieusement les règles dupliquées.
        _ensure_portal_rule(ssh)

        if client_ip == PORTAL_SERVER_IP:
            # Le portail lui-même est le client (le courtier se connecte directement).
            # The permanent rule above covers this — no per-session rule needed.
            logger.info(
                f"mysql_broker: client_ip={client_ip} is the portal server "
                f"— permanent rule covers it, no per-session rule added"
            )
        else:
            # Client sur une machine différente — ajout d'une règle par session
            ufw_comment = f"ZT-mysql-{temp_user}"
            out, err, code = _run(
                ssh,
                f"sudo ufw allow from {client_ip} to any port 3306 "
                f"comment '{ufw_comment}'"
            )
            if code == 0:
                logger.info(
                    f"mysql_broker: per-session UFW rule added — "
                    f"allow {client_ip} -> port 3306 [{ufw_comment}]"
                )
            else:
                logger.warning(
                    f"mysql_broker: per-session UFW rule failed for "
                    f"{client_ip}: {err}"
                )

        # Re-sink deny rules so they sit below all allow rules
        _sink_deny_rules(ssh)
        ssh.close()

    except Exception as e:
        logger.warning(f"mysql_broker: UFW management failed — {e}")
        # Non-fatal — l'utilisateur MySQL est créé, l'accès fonctionne

    # ── Step 3: Track session and schedule revocation ─────────
    logger.info(
        f"mysql_broker: provisioned '{temp_user}' "
        f"client_ip={client_ip} level='{access_level}' "
        f"expires={expiry.isoformat()}"
    )

    now_iso = datetime.utcnow().isoformat() + "Z"
    with _lock:
        _active_sessions[temp_user] = {
            "expiry":       expiry,
            "client_ip":    client_ip,
            "device_id":    device_id,
            "user_id":      user_id,
            "user_roles":   user_roles or [],
            "resource_id":  resource_id,
            "access_level": access_level,
            "started_at":   now_iso,
        }

    _append_session_log({
        "resource":     resource_id or "mysql",
        "protocol":     "MySQL",
        "temp_user":    temp_user,
        "user_id":      user_id,
        "user_roles":   user_roles or [],
        "access_level": access_level,
        "client_ip":    client_ip,
        "started_at":   now_iso,
        "ended_at":     None,
        "ended_reason": None,
    })

    _schedule_revocation(temp_user, duration_minutes * 60)

    return {
        "host":             MYSQL_HOST,
        "port":             MYSQL_PORT,
        "database":         MYSQL_DATABASE,
        "username":         temp_user,
        "password":         temp_pass,
        "expires_at":       expiry.isoformat() + "Z",
        "duration_minutes": duration_minutes,
    }


def revoke_access(temp_user: str) -> bool:
    """
    Kill active MySQL connections, drop the temporary user,
    remove the per-session UFW rule (if applicable),
    and re-sink deny rules to the bottom.
    Returns True on success, False on failure.
    """
    success = True

    # Récupération des données de session avant suppression du suivi
    with _lock:
        session_data = _active_sessions.get(temp_user, {})
        client_ip    = session_data.get("client_ip", "")

    # ── Step 1: Kill active MySQL connections ─────────────────
    try:
        conn   = _get_mysql_connection()
        cursor = conn.cursor()

        # Find and kill any active connections for this user
        cursor.execute(
            "SELECT id FROM information_schema.processlist "
            "WHERE user = %s;",
            (temp_user,)
        )
        for (pid,) in cursor.fetchall():
            try:
                cursor.execute(f"KILL CONNECTION {pid};")
                logger.info(f"mysql_broker: killed connection pid={pid} for '{temp_user}'")
            except Exception:
                pass

        # Drop the temporary user
        cursor.execute(f"DROP USER IF EXISTS '{temp_user}'@'%';")
        conn.commit()
        cursor.close()
        conn.close()
        logger.info(f"mysql_broker: dropped MySQL user '{temp_user}'")

    except Exception as e:
        logger.error(f"mysql_broker: MySQL revocation failed — {e}")
        success = False

    # ── Step 2: Remove per-session UFW rule ───────────────────
    try:
        ssh = _get_ssh_client()

        if client_ip and client_ip != PORTAL_SERVER_IP:
            ufw_comment = f"ZT-mysql-{temp_user}"

            out, _, _ = _run(
                ssh,
                f"sudo ufw status numbered | grep '{ufw_comment}' | "
                f"awk -F'[][]' '{{print $2}}'"
            )

            rule_numbers = [
                r.strip() for r in out.splitlines()
                if r.strip().isdigit()
            ]

            if rule_numbers:
                for num in sorted(rule_numbers, reverse=True):
                    _run(ssh, f"echo 'y' | sudo ufw delete {num}")
                    logger.info(
                        f"mysql_broker: removed UFW rule #{num} "
                        f"for {client_ip} [{ufw_comment}]"
                    )
            else:
                logger.warning(
                    f"mysql_broker: no UFW rule found for "
                    f"comment '{ufw_comment}' — may already be removed"
                )

        elif client_ip == PORTAL_SERVER_IP:
            logger.info(
                f"mysql_broker: client_ip is portal server — "
                f"permanent UFW rule preserved, no per-session rule to remove"
            )

        # Re-sink deny rules to bottom
        _sink_deny_rules(ssh)
        ssh.close()

    except Exception as e:
        logger.warning(f"mysql_broker: UFW revocation failed — {e}")

    with _lock:
        _active_sessions.pop(temp_user, None)

    # Marquage de l'entrée du journal de session comme terminée
    ended_iso = datetime.utcnow().isoformat() + "Z"
    with _lock:
        for entry in reversed(_session_log):
            if entry.get("temp_user") == temp_user and entry.get("ended_at") is None:
                entry["ended_at"]     = ended_iso
                entry["ended_reason"] = "revoked"
                break

    logger.info(
        f"mysql_broker: fully revoked '{temp_user}' "
        f"client_ip={client_ip}"
    )
    return success


def get_session_log() -> list:
    """Return the session history log (most recent first)."""
    with _lock:
        return list(reversed(_session_log))


def get_active_sessions() -> dict:
    """Return all currently active temporary MySQL sessions."""
    with _lock:
        return dict(_active_sessions)


# ── Internal ──────────────────────────────────────────────────

def _schedule_revocation(temp_user: str, delay_seconds: int) -> None:
    """Schedule automatic revocation after session duration."""
    def _revoke():
        logger.info(f"mysql_broker: timer fired — revoking '{temp_user}'")
        revoke_access(temp_user)

    timer        = threading.Timer(delay_seconds, _revoke)
    timer.daemon = True
    timer.start()
    logger.info(
        f"mysql_broker: auto-revocation scheduled for '{temp_user}' "
        f"in {delay_seconds}s ({delay_seconds // 60} min)"
    )
